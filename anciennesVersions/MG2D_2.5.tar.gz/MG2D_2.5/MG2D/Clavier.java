package MG2D;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Cette classe implémente les méthodes de KeyListener permettant la gestion du clavier.
 * <br /><br />
 * Elle permet de gérer le clavier dans des applications développées avec la bibliothèque MG2D.<br />
 * A la façon d'une borne d'arcade, elle gère uniquement les touches directionnelles, 6 lettres (a/z/e et q/s/d), la barre espace et le bouton entrée.<br />
 * Elle fonctionne sur le principe de booléen que l'on change quand on appuie ou relache les touches.<br />
 * Si l'utilisateur souhaite implémenter la gestion de davantage de touches, il peut reprendre ce code et le modifier selon ses besoins.
 * @author Equipe 2D, Rémi Synave
 * @version 2.2
 */
public class Clavier implements KeyListener {

    // Attributs //
	
    private boolean gauche;
    private boolean droite;
    private boolean haut;
    private boolean bas;
	
    private boolean espace;
    private boolean entree;
	
    private boolean a;
    private boolean z;
    private boolean e;
    private boolean q;
    private boolean s;
    private boolean d;
    
    // Constructeur //
	
    /**
     * Crée un clavier et initialise tous les attributs à faux pour touches relachés.
     */
    public Clavier () {
		
	gauche = droite = haut = bas = false;
		
	espace = entree = false;
		
	a = z = e = q = s = d = false;
    }
	
    // Accesseurs //
    
    // Getter //
    
    /**
     * Permet de savoir si la touche "flèche gauche" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "flèche gauche" : vrai pour appuyée, faux sinon.
     */
    public boolean getGauche () {
		
	return gauche;
    }
	
    /**
     * Permet de savoir si la touche "flèche droite" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "flèche droite" : vrai pour appuyée, faux sinon.
     */
    public boolean getDroite () {
		
	return droite;
    }
	
    /**
     * Permet de savoir si la touche "flèche haut" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "flèche haut" : vrai pour appuyée, faux sinon.
     */
    public boolean getHaut () {
		
	return haut;
    }
	
    /**
     * Permet de savoir si la touche "flèche bas" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "flèche bas" : vrai pour appuyée, faux sinon.
     */
    public boolean getBas () {
		
	return bas;
    }
	
    /**
     * Permet de savoir si la touche "espace" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "espace" : vrai pour appuyée, faux sinon.
     */
    public boolean getEspace () {
		
	return espace;
    }
	
    /**
     * Permet de savoir si la touche "entrée" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "entrée" : vrai pour appuyée, faux sinon.
     */
    public boolean getEntree () {
		
	return entree;
    }
	
    /**
     * Permet de savoir si la touche "a" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "a" : vrai pour appuyée, faux sinon.
     */
    public boolean getA () {
		
	return a;
    }
	
    /**
     * Permet de savoir si la touche "z" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "z" : vrai pour appuyée, faux sinon.
     */
    public boolean getZ () {
		
	return z;
    }
	
    /**
     * Permet de savoir si la touche "e" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "e" : vrai pour appuyée, faux sinon.
     */
    public boolean getE () {
		
	return e;
    }
	
    /**
     * Permet de savoir si la touche "q" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "q" : vrai pour appuyée, faux sinon.
     */
    public boolean getQ () {
		
	return q;
    }
	
    /**
     * Permet de savoir si la touche "s" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "s" : vrai pour appuyée, faux sinon.
     */
    public boolean getS () {
		
	return s;
    }
	
    /**
     * Permet de savoir si la touche "d" est appuyée ou non.
     * @return retourne la valeur du booléen correspondant à la touche "d" : vrai pour appuyée, faux sinon.
     */
    public boolean getD () {
		
	return d;
    }
		
    // Setter //
	
    /**
     * Permet de simuler l'appui ou non sur la touche "flèche gauche".
     * @param gauche le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setGauche ( boolean gauche ) {
		
	this.gauche = gauche;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "flèche droite".
     * @param droite le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setDroite ( boolean droite ) {
		
	this.droite = droite;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "flèche haut".
     * @param haut le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setHaut( boolean haut ) {
		
	this.haut = haut;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "flèche bas".
     * @param bas le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setBas ( boolean bas ) {
		
	this.bas = bas;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "espace".
     * @param espace le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setEspace ( boolean espace ) {
		
	this.espace = espace;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "entrée".
     * @param entree le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setEntree ( boolean entree ) {
		
	this.entree = entree;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "a".
     * @param a le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setA ( boolean a ) {
		
	this.a = a;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "z".
     * @param z le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setZ ( boolean z ) {
		
	this.z = z;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "e".
     * @param e le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setE ( boolean e ) {
		
	this.e = e;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "q".
     * @param q le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setQ ( boolean q ) {
		
	this.q = q;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "s".
     * @param s le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setS ( boolean s ) {
		
	this.s = s;
    }
	
    /**
     * Permet de simuler l'appui ou non sur la touche "d".
     * @param d le paramètre doit prendre la valeur "true" si on veut simuler l'appui sur la touche, "false" dans le cas contraire.
     */
    public void setD ( boolean d ) {
		
	this.d = d;
    }
		
    // Méthodes //
	
    /**
     * Implémentation de la méthode KeyReleased - méthode appelée automatiquement lors d'un événement clavier.
     * <br /><br />
     * Elle permet de mettre à jour les valeurs des attributs en fonction des interactions au clavier.<br />
     * Ici, si une touche est relachée, l'attribut gérant cette touche est mis à jour.<br />
     * Pour la gestion sur l'appui des touches, voir la méthode keyPressed ( KeyEvent k ).
     * @param k un événement clavier.
     * @see <a href="https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyEvent.html" target="_blank">KeyEvent</a>
     * @see <a href="https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyListener.html" target="_blank">KeyListener</a>
     * @see #keyPressed keyPressed ( KeyEvent k )
     */
    @Override
    public void keyReleased ( KeyEvent k ) {
		
	switch ( k.getKeyCode() ) {
		
	case KeyEvent.VK_LEFT :
	    gauche = false;				
	    break;
				
	case KeyEvent.VK_RIGHT :
	    droite = false;				
	    break;	
				
	case KeyEvent.VK_UP :
	    haut = false;
	    break;
				
	case KeyEvent.VK_DOWN :
	    bas = false;				
	    break;
				
	case KeyEvent.VK_SPACE :
	    espace = false;			
	    break;
			
	case KeyEvent.VK_ENTER :
	    entree = false;
	    break;
				
	case KeyEvent.VK_A :
	    a = false;			
	    break;
			
	case KeyEvent.VK_Z :
	    z = false;			
	    break;
			
	case KeyEvent.VK_E :
	    e = false;			
	    break;
				
	case KeyEvent.VK_Q :
	    q = false;			
	    break;
				
	case KeyEvent.VK_S :
	    s = false;			
	    break;
				
	case KeyEvent.VK_D :
	    d = false;			
	    break;
	}		
    }
	
    /**
     * Implémentation de la méthode KeyTyped - méthode appelée automatiquement lors d'un événement clavier.
     * <br /><br />
     * Cette méthode doit être implémentée mais est inutile dans ce moteur.
     */
    public void keyTyped ( KeyEvent k ) {}
	
    /**
     * Implémentation de la méthode KeyPressed - méthode appelée automatiquement lors d'un événement clavier.
     * <br /><br />
     * Elle permet de mettre à jour les valeurs des attributs en fonction des interactions au clavier.<br />
     * Ici, si une touche est pressée, l'attribut gérant cette touche est mis à jour.<br />
     * Pour la gestion du relachement des touches, voir la méthode keyReleased ( KeyEvent k ).
     * @param k un événement clavier.
     * @see <a href="https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyEvent.html" target="_blank">KeyEvent</a>
     * @see <a href="https://docs.oracle.com/javase/7/docs/api/java/awt/event/KeyListener.html" target="_blank">KeyListener</a>
     * @see #keyReleased keyReleased ( KeyEvent k )
     */
    public void keyPressed ( KeyEvent k ) {
	
	switch ( k.getKeyCode() ) {
		
	case KeyEvent.VK_LEFT :
	    gauche = true;				
	    break;
				
	case KeyEvent.VK_RIGHT :
	    droite = true;				
	    break;	
				
	case KeyEvent.VK_UP :
	    haut = true;
	    break;
				
	case KeyEvent.VK_DOWN :
	    bas = true;				
	    break;
				
	case KeyEvent.VK_SPACE :
	    espace = true;			
	    break;
				
	case KeyEvent.VK_ENTER :
	    entree = true;
	    break;
				
	case KeyEvent.VK_A :
	    a = true;			
	    break;
			
	case KeyEvent.VK_Z :
	    z = true;			
	    break;
			
	case KeyEvent.VK_E :
	    e = true;			
	    break;
				
	case KeyEvent.VK_Q :
	    q = true;			
	    break;
				
	case KeyEvent.VK_S :
	    s = true;			
	    break;
				
	case KeyEvent.VK_D :
	    d = true;			
	    break;
	}		
    }
}
