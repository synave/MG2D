package MG2D.geometrie;

import java.awt.Color;

/**
 * DOC A ECRIRE.<br />
 * A ECRIRE
 * @author Rémi Synave
 * @version 1.0
 */

public class Couleur extends Color{
    
    /**
     * DOC A ECRIRE.<br />
     * DOC A ECRIRE.
     */
    public static Couleur NOIR = new Couleur (0,0,0);
    public static Couleur BLANC = new Couleur(255,255,255);
    public static Couleur ROUGE = new Couleur(255,0,0);
    public static Couleur VERT = new Couleur(0,255,0);
    public static Couleur BLEU = new Couleur(0,0,255);
    public static Couleur CYAN = new Couleur(0,255,255);
    public static Couleur GRIS = new Couleur(127,127,127);
    public static Couleur GRIS_FONCE = new Couleur(96,96,96);
    public static Couleur GRIS_CLAIR = new Couleur(158,158,158);
    public static Couleur MAGENTA = new Couleur(255,0,255);
    public static Couleur ORANGE = new Couleur(255,127,0);
    public static Couleur ROSE = new Couleur(249,66,158);
    public static Couleur JAUNE = new Couleur(255,255,0);
    
    /**
     * DOC A ECRIRE.<br />
     * DOC A ECRIRE.
     */
    public Couleur(int r, int v, int b){
	super(r,v,b);
    }

    /**
     * DOC A ECRIRE.<br />
     * DOC A ECRIRE.
     */
    public Couleur(Color c){
	super(c.getRed(),c.getGreen(),c.getBlue());
    }

    /**
     * DOC A ECRIRE.<br />
     * DOC A ECRIRE.
     */
    public Couleur assombrir(){
	return new Couleur(super.darker());
    }
    
    /**
     * DOC A ECRIRE.<br />
     * DOC A ECRIRE.
     */
    public Couleur eclaircir(){
	return new Couleur(super.brighter());
    }
    
}
