import MG2D.*;

import MG2D.geometrie.*;

import java.awt.Color;

public class Rotation {
	
    public static void main ( String [] args ) {
		
    	Color rouge = Color.red;
	    	
    	Fenetre f = new Fenetre ( "Rotation", 800, 600 );
 	
    	double delta = 0;
    	int numcolor = 0;
    	
    	Point a = new Point ( ( int ) ( 400 + Math.cos ( delta + Math.PI ) * 100 ), ( int ) ( 300 + Math.sin ( delta + Math.PI ) * 100 ) );
    	Point b = new Point ( ( int ) ( 400 + Math.cos ( delta +3.0 * Math.PI / 2.0 ) * 100 ), ( int ) ( 300 + Math.sin ( delta + 3.0 * Math.PI / 2.0 ) * 100 ) );
    	Point c = new Point ( ( int ) ( 400 + Math.cos ( delta ) * 100 ), ( int ) ( 300 + Math.sin ( delta ) * 100 ) );
    	Point d = new Point ( ( int ) ( 400 + Math.cos ( delta + Math.PI / 2.0 ) * 100 ), ( int ) ( 300 + Math.sin ( delta + Math.PI / 2.0 ) * 100 ) );
    			    
    	Triangle t1 = new Triangle ( rouge, a, b, c, true);		
    	Triangle t2 = new Triangle ( Color.green, a, c, d, true );
    	
    	f.ajouter ( t1 );
    	f.ajouter ( t2 );
    	
    	while ( true ) {
    		
    	    try {
    	    	
    	    	Thread.sleep ( 10 );
    	    }
    	    
    	    catch ( Exception e ) {
    	    	
    	    	System.out.println ( e );
    	    }
    	    
    	    delta = delta + Math.PI / 80.0;
    	    
    	    if ( delta > 360 )
    	    	delta -= 360;
    	    
    	    t1.getA().setX ( ( int ) ( 400 + Math.cos ( delta + Math.PI ) * 100 ) );
    	    t1.getA().setY ( ( int ) ( 300 + Math.sin ( delta + Math.PI ) * 100 ) );
    	    
    	    t1.getB().setX ( ( int ) ( 400 + Math.cos ( delta + 3.0 * Math.PI / 2.0 ) * 100 ) );
    	    t1.getB().setY ( ( int ) ( 300 + Math.sin ( delta + 3.0 * Math.PI / 2.0 ) * 100 ) );
    	    
    	    t1.getC().setX ( ( int ) ( 400 + Math.cos ( delta ) * 100 ) );
    	    t1.getC().setY ( ( int ) ( 300 + Math.sin ( delta ) * 100 ) ); 

	    t2.getA().setX ( ( int ) ( 400 + Math.cos ( delta + Math.PI ) * 100 ) );
    	    t2.getA().setY ( ( int ) ( 300 + Math.sin ( delta + Math.PI ) * 100 ) );
    	    
    	    t2.getB().setX ( ( int ) ( 400 + Math.cos ( delta ) * 100 ) );
    	    t2.getB().setY ( ( int ) ( 300 + Math.sin ( delta ) * 100 ) ); 
    	    
    	    t2.getC().setX ( ( int ) ( 400 + Math.cos ( delta + Math.PI / 2.0 ) * 100 ) );
    	    t2.getC().setY ( ( int ) ( 300 + Math.sin ( delta + Math.PI / 2.0 ) * 100 ) );
    	    
    	    f.rafraichir();    	    
	}
    }
}
