import MG2D.*;
import MG2D.geometrie.*;


// permet de tester la fonctionnalité des collisions
public class Test_Animation {
	
    public static void main ( String [] args ) {

	int largeur=800, hauteur=600;
		
	Fenetre f = new Fenetre ( "Collision", largeur, hauteur );
		
	Clavier clavier = f.getClavier();
		
	Animation a = new Animation ( "img/","0","9","png", new Point(10,10) );
		
	f.ajouter ( a );
		
	while ( true ) {
			
	    try {				
		Thread.sleep ( 500 );
	    }		
	    catch ( Exception e ) {				
		System.out.println ( e );
	    }
			
	    if ( clavier.getGauche() && a.getA().getX()-10 > 0 )
		a.translater(-10,0);
			
			
	    if ( clavier.getDroite() && a.getB().getX()+10 < largeur )
		a.translater(10,0);
   
			
	    if ( clavier.getHaut() && a.getA().getY()+10 > 0 )
		a.translater(0,10);
			
			
	    if ( clavier.getBas() && a.getB().getY()-10 < hauteur )
		a.translater(0,-10);
					
	    f.rafraichir();
	}
    }
}
