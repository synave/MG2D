package MG2D.geometrie;


import java.awt.Graphics;
import java.awt.Image;

import java.io.File;
import java.io.IOException;

import java.net.URL;

import javax.imageio.ImageIO;

/**
 * Cette classe est un cas particulier qui découle de la classe Rectangle.<br />
 * En effet, il s'agit d'une Texture qui est un Rectangle de taille fixe sur lequel on applique une image.<br />
 * Ainsi, contrairement au Rectangle classique, une modification d'un coin entraine la modification automatique de l'autre coin. <br />
 * Elle hérite de la classe Rectangle afin que toutes les méthodes de la classe Rectangle s'applique également à celle-ci.<br />
 * <br /><br />
 * Une Texture est définie par une Image et un booléen indiquant si le fond est transparent ou non.
 * @author Equipe 2D
 * @version 2.0
 */
public class Texture extends Rectangle {
	
    // Attributs //
	
    private Image img = null;
	
    private boolean transparent = true;	// Détermine si le fond de l'image est transparent ou non //
	
    // Constructeurs //
	
    // Sans couleur de fond //
	
    /**
     * Construit une Texture à partir d'une chaîne de caractères et d'un Point.<br />
     * <br /><br />
     * La chaîne de caractères représente le chemin d'accès vers l'image.
     * @param chemin Chaîne de caractères représente le chemin d'accès vers l'image.
     * @param a	Point ( x min, y min )
     */
    public Texture ( String chemin, Point a ) {
		
	super ( a, 0, 0 );
		
	try {
			
	    //URL url = getClass().getClassLoader().getResource ( chemin );
	    //img = ImageIO.read ( url );
	    img = ImageIO.read(new File(chemin));
	}
		
	catch ( IOException e ) {
			
	    System.out.println ("[!] Erreur : L'image "+ chemin +" est introuvable.\n" + e);
	}
		
	int largeur = img.getWidth ( null );
	int hauteur = img.getHeight ( null );
		
	super.setB ( new Point ( a.getX() + largeur, a.getY() + hauteur ) );
    }

    /**
     * Construit une Texture à partir d'une chaîne de caractères, d'un Point, une largeur et une hauteur.<br />
     * <br /><br />
     * La chaîne de caractères représente le chemin d'accès vers l'image.
     * @param chemin Chaîne de caractères représente le chemin d'accès vers l'image.
     * @param a	Point ( x min, y min )
     * @param larg largeur de l'image
     * @param haut hauteur de l'image
     */
    public Texture ( String chemin, Point a, int larg, int haut ) {
		
	super ( a, 0, 0 );
		
	try {
			
	    //URL url = getClass().getClassLoader().getResource ( chemin );
	    //img = ImageIO.read ( url );
	    img = ImageIO.read(new File(chemin));
	}
		
	catch ( IOException e ) {
			
	    System.out.println ("[!] Erreur : L'image "+ chemin+ " est introuvable.\n" + e);
	}
		
	super.setB ( new Point ( a.getX() + larg, a.getY() + haut ) );
    }
	
    // Avec couleur de fond //

    /**
     * Construit une Texture à partir d'une chaîne de caractères et d'un Point.
     * <br /><br />
     * La chaîne de caractères représente le chemin d'accès vers l'image.
     * @param couleur Couleur de fond
     * @param chemin Chaîne de caractères représente le chemin d'accès vers l'image.
     * @param a	Point ( x min, y min )
     */
    public Texture ( Couleur couleur, String chemin, Point a ) {
		
	super ( couleur, a, 0, 0 );
		
	try {
			
	    URL url = getClass().getClassLoader().getResource ( chemin );
	    img = ImageIO.read ( url );
	}
		
	catch ( IOException e ) {
			
	    System.out.println ("[!] Erreur : L'image "+ chemin +" est introuvable.\n" + e);
	}
		
	int largeur = img.getWidth ( null );
	int hauteur = img.getHeight ( null );
		
	setB ( new Point ( a.getX() + largeur, a.getY() + hauteur ) );
		
	transparent = false;
    }

    /**
     * Construit une Texture à partir d'une chaîne de caractères et d'un Point.
     * <br /><br />
     * La chaîne de caractères représente le chemin d'accès vers l'image.
     * @param couleur Couleur de fond
     * @param chemin Chaîne de caractères représente le chemin d'accès vers l'image.
     * @param a	Point ( x min, y min )
     * @param larg largeur de l'image
     * @param haut hauteur de l'image
     */
    public Texture ( Couleur couleur, String chemin, Point a, int larg, int haut ) {
		
	super ( couleur, a, 0, 0 );
		
	try {
			
	    URL url = getClass().getClassLoader().getResource ( chemin );
	    img = ImageIO.read ( url );
	}
		
	catch ( IOException e ) {
			
	    System.out.println ("[!] Erreur : L'image "+chemin+" est introuvable.\n" + e);
	}
		
	setB ( new Point ( a.getX() + larg, a.getY() + haut ) );
		
	transparent = false;
    }
	
    // Accesseurs //

    // Getter //
	
    /**
     * Retourne l'image img.
     * @return img Image
     */
    public Image getImg () {
		
	return img;
    }
	
    /**
     * Retourne la transparence de l'image.
     * @return transparent Booléen
     */
    public boolean getTransparent () {
		
	return transparent;
    }
	
    // Setter //
	
    /**
     * Permet d'attribuer une image à img.<br />
     * Setter par recopie.
     * @param img Image
     */
    public void setImg ( Image img ) {
		
	this.img = img;
	int largeur = img.getWidth ( null );
	int hauteur = img.getHeight ( null );
	
	setB ( new Point ( getA().getX() + largeur, getA().getY() + hauteur ) );
    }
	
    /**
     * Permet d'attribuer une image à img.<br />
     * Créé une nouvelle image grâce au chemin indiqué en paramètre.
     * @param chemin Chemin d'accès vers une image
     */
    public void setImg ( String chemin ) {
		
	try {
			
	    URL url = getClass().getClassLoader().getResource ( chemin );
	    img = ImageIO.read ( url );
	}
		
	catch ( IOException e ) {
			
	    System.out.println ("[!] Erreur : L'image "+chemin+" est introuvable.\n" + e);
	}

	int largeur = img.getWidth ( null );
	int hauteur = img.getHeight ( null );
		
	super.setB ( new Point ( getA().getX() + largeur, getA().getY() + hauteur ) );

    }

    
    /**
     * Permet de rendre le fond de l'image transparent.
     * @param transparent Booléen
     */
    public void setTransparent ( boolean transparent ) {
		
	this.transparent = transparent;
    }

    /**
     * Permet de modifier la position du point A. La position du point B est également modifiée afin que la texture ne soit pas étirée.
     * @param aa Point
     */
    public void setA(Point aa){
	int largeur = getLargeur();
	int hauteur = getHauteur();
	super.setA(aa);
	super.setB(new Point(getA().getX()+largeur,getA().getY()+hauteur));
    }

    /**
     * Permet de modifier la position du point B. La position du point A est également modifiée afin que la texture ne soit pas étirée.
     * @param bb Point
     */
    public void setB(Point bb){
	int largeur = getLargeur();
	int hauteur = getHauteur();
	super.setB(bb);
	super.setA(new Point(getB().getX()-largeur,getB().getY()-hauteur));
    }

    // Méthode //
	
    /**
     * Implémentation de la méthode afficher() de la classe abstraite Dessin.<br />
     * Elle permet d'afficher une Texture sur le Panneau.
     * <br /><br />
     * On vérifie d'abord si l'image est transparente ou non, puis on utilise la méthode drawImage adéquate.
     * @param g Graphics.
     */
    public void afficher ( Graphics g ) {
		
	if ( transparent )
	    g.drawImage ( img, this.getA().getX(), (int)g.getClipBounds().getHeight()-this.getA().getY()-getHauteur(), getLargeur(), getHauteur(), null );
		
	else
	    g.drawImage ( img, this.getA().getX(), (int)g.getClipBounds().getHeight()-this.getA().getY()-getHauteur(), getLargeur(), getHauteur(), getCouleur(), null );
    }

    /**
     * Méthode equals.
     */
    public boolean equals(Object obj){
	if (obj==this) { 
            return true; 
        } 
  
        // Vérification du type du paramètre 
        if (obj instanceof Texture) { 
            // Vérification des valeurs des attributs 
	    Texture other = (Texture) obj; 
	    return super.equals(other) && img.equals(other.img) && transparent==other.transparent;
	}
	return false;
    }
}
