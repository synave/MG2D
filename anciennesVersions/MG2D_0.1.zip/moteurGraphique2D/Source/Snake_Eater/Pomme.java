import projet_2D.geometrie.Carre;
import projet_2D.geometrie.Point;

import java.awt.Color;

public class Pomme {
	
// Attributs //
	
	private Carre c;
	private boolean etat;
	
// Constructeur //
	
	public Pomme ( Point a ) {
		
		c = new Carre ( Color.green, a, 10, true );
		etat = false;
	}

// Accesseurs //
	
	// Getter //
	
	public Carre getC () {
		
		return c;
	}
	
	public boolean getEtat () {
		
		return etat;
	}
	
	// Setter //
	
	public void setEtat ( boolean etat ) {
		
		this.etat = etat;
	}
}
