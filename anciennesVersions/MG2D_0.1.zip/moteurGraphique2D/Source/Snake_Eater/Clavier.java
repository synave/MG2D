import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Clavier implements KeyListener {
	
// Attributs //
	private boolean gauche;
	private boolean droite;
	private boolean haut;
	private boolean bas;
		
// Constructeur //
	
	public Clavier () {
		
		gauche = haut = bas = false;
		droite = true;
	}
	
// Accesseurs //
	
	// Getter //
	
	public boolean getGauche () {
		
		return gauche;
	}
	
	public boolean getDroite () {
		
		return droite;
	}
	
	public boolean getHaut () {
		
		return haut;
	}
	
	public boolean getBas () {
		
		return bas;
	}
		
	// Setter //
	
	public void setGauche ( boolean gauche ) {
		
		this.gauche = gauche;
	}
	
	public void setDroite ( boolean droite ) {
		
		this.droite = droite;
	}
	
	public void setHaut( boolean haut ) {
		
		this.haut = haut;
	}
	
	public void setBas ( boolean bas ) {
		
		this.bas = bas;
	}
		
// M�thodes //
	
	public void keyReleased ( KeyEvent e ) {
		
		switch ( e.getKeyCode() ) {
			
			case KeyEvent.VK_LEFT :
				
				if ( !droite ) {
					
					gauche = true;
					droite = false;
					haut = false;
					bas = false;
				}				
				
				break;
				
			case KeyEvent.VK_RIGHT :
				
				if ( !gauche ) {
					
					gauche = false;
					droite = true;
					haut = false;
					bas = false;
				}	
				
				break;	
				
			case KeyEvent.VK_UP :
				
				if ( !bas ) {
					
					gauche = false;
					droite = false;
					haut = true;
					bas = false;
				}	
				
				break;
				
			case KeyEvent.VK_DOWN :
				
				if ( !haut ) {
					
					gauche = false;
					droite = false;
					haut = false;
					bas = true;
				}	
				
				break;
		}		
	}
	
	public void keyTyped ( KeyEvent e ) {}
	
	public void keyPressed ( KeyEvent e ) {}
}
