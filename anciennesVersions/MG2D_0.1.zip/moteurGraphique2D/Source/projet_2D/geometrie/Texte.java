package projet_2D.geometrie;

import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;

/**
 * Cette classe permet la cr�ation de Texte.<br />
 * Un Texte est d�finie par une cha�ne de caract�res, d'une police de texte et d'un Point.
 * @author Equipe 2D
 * @version 1.0
 */
public class Texte extends Dessin {
	
// Attributs //
	
	private String texte;
	private Font police;
	
	private Point a;	// Il s'agit du point central du texte /!\ //
	
// Constructeur //
	
	// Couleur par d�faut //
	
	/**
	 * Construit un Texte � partir d'une cha�ne de caract�res, d'une police et d'un Point.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.<br />
	 * /!\ Attention ! Le Point correspondant au centre du Texte.
	 * @param texte Cha�ne de caract�res
	 * @param police Police de texte
	 * @param a Point
	 */
	public Texte ( String texte, Font police, Point a ) {
		
		super ( Color.black );
		
		this.texte = texte;
		this.police = police;
		this.a = a;
	}
	
	// Couleur d�finie par l'utilisateur //
	
	/**
	 * Construit un Texte � partir d'une cha�ne de caract�res, d'une police et d'un Point.
	 * @param couleur Couleur du Texte
	 * @param texte Cha�ne de caract�res
	 * @param police Police de texte
	 * @param a Point
	 */
	public Texte ( Color couleur, String texte, Font police, Point a ) {
		
		super ( couleur );
		
		this.texte = texte;
		this.police = police;
		this.a = a;
	}
	
// Accesseurs //
	
	// Getter //
	
	/**
	 * Retourne la cha�ne de caract�res texte.
	 * @return texte Cha�ne de caract�res
	 */
	public String getTexte () {
		
		return texte;
	}
	
	/**
	 * Retourne la police de texte.
	 * @return police Font du Texte
	 */
	public Font getPolice () {
		
		return police;
	}	
	
	/**
	 * Retourne le point central.
	 * @return a Point central du Texte.
	 */
	public Point getA () {
		
		return a;
	}
	
	/**
	 * Impl�mentation de la m�thode getBoiteEnglobante() de la classe abstraite Dessin.<br />
	 * Elle retourne une BoiteEnglobante entourant le Texte.<br /><br />
	 * /!\ Attention ! Cette m�thode n'est pas r�dig�e !<br />
	 * N'essayez pas de tester l'intersection entre un Texte et un objet !
	 * @return BoiteEnglobante BoiteEnglobante entourant la Ligne.
	 * @throws java.lang.NullPointerException
	 */
	public BoiteEnglobante getBoiteEnglobante() {

		// TODO : travail � faire, si l'envie vous prend :) //
		return null;
	}
	
	// Setter //
	
	/**
	 * Permet d'attribuer une cha�ne de caract�res � texte.
	 * @param texte Cha�ne de caract�res
	 */
	public void setTexte ( String texte ) {
		
		this.texte = texte;
	}
	
	/**
	 * Permet d'attribuer une Font � police.
	 * @param police
	 */
	public void setPolice ( Font police ) {
		
		this.police = police;
	}
	
	/**
	 * Permet d'attribuer un Point au Point a.
	 * @param a Point central du Texte
	 */
	public void setA ( Point a ) {
		
		this.a = a;
	}
	
// M�thodes //

	/**
	 * Impl�mentation de la m�thode afficher() de la classe abstraite Dessin.<br />
	 * Elle permet d'afficher un Texte sur le Panneau.
	 * <br /><br />
	 * On r�cup�re d'abord la couleur et la police. Une fois la police r�cup�r�e, on cr�e un FontMetrics afin d'avoir la dimension en largeur du texte ce qui nous permets d'afficher correctement le Texte avec le Point central donn� par l'utilisateur.
	 * @param g Graphics.
	 */
	public void afficher ( Graphics g ) {
		
        g.setColor ( getCouleur() );
        g.setFont ( police );
        
        FontMetrics metr = g.getFontMetrics ( police );
        
        g.drawString ( texte, a.getX() - ( metr.stringWidth ( texte ) / 2 ), a.getY() );
	}
}
