package projet_2D.geometrie;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Cette classe permet la cr�ation de Point.<br />
 * Un Point est d�fini par deux entiers (abscisse et ordonn�e).
 * @author Equipe 2D
 * @version 1.0
 */
public class Point extends Dessin {
	
// Attributs //
	
	private int x;	// Abscisse //
	private int y;	// Ordonn�e //
	
// Constructeurs //
	
	// Sans couleur //
	
	/**
	 * Construit un Point � partir d'un Point.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param p Point.
	 */
	public Point ( Point p ) {
		
		super ( Color.black );
		
		x = p.getX();
		y = p.getY();
	}
	
	/**
	 * Construit un Point � partir de deux entiers.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param x Abscisse.
	 * @param y Ordonn�e.
	 */
	public Point ( int x, int y ) {
		
		super ( Color.black );
		
        this.x = x;
        this.y = y;
	}
	
	// Avec couleur //
	
	/**
	 * Construit un Point � partir d'un Point.
	 * @param couleur Couleur de l'objet.
	 * @param p Point.
	 */
	public Point ( Color couleur, Point p ) {
		
		super ( couleur );
		
		x = p.getX();
		y = p.getY();
	}
	
	/**
	 * Construit un Point � partir de deux entiers.
	 * @param couleur Couleur de l'objet.
	 * @param x Abscisse.
	 * @param y Ordonn�e.
	 */
	public Point ( Color couleur, int x, int y ) {
		
		super ( couleur );
		
        this.x = x;
        this.y = y;
	}
	
// Accesseurs //
	
	// Getter //
	
	/**
	 * Retourne la valeur de x.
	 * @return x Abscisse.
	 */
	public int getX () {
		
		return x;
	}
	
	/**
	 * Retourne la valeur de y.
	 * @return y Ordonn�e.
	 */
	public int getY () {
		
		return y;
	}
	
	/**
	 * Impl�mentation de la m�thode getBoiteEnglobante() de la classe abstraite Dessin.<br />
	 * Elle retourne une BoiteEnglobante qui est le Point lui-m�me.
	 * @return BoiteEnglobante BoiteEnglobante qui est le Point lui-m�me.
	 */
	public BoiteEnglobante getBoiteEnglobante () {
		
		return new BoiteEnglobante ( new Point ( x, y ),
									new Point ( x, y ) );
	}
	
	// Setter //
	
	/**
	 * Permet d'attribuer une valeur � x.
	 * @param x Abscisse.
	 */
	public void setX ( int x ) {
		
		this.x = x;
	}
	
	/**
	 * Permet d'attribuer une valeur � y.
	 * @param y Ordonn�e.
	 */
	public void setY ( int y ) {
		
		this.y = y;
	}
	
// M�thodes //
	
	/**
	 * Impl�mentation de la m�thode afficher() de la classe abstraite Dessin.<br />
	 * Elle permet d'afficher un Point sur le Panneau.
	 * <br /><br />
	 * On r�cup�re d'abord la couleur de l'objet afin de le dessiner dans la bonne couleur. Puis on utilise l'affichage avec drawLine().
	 * @param g Graphics.
	 */
	public void afficher ( Graphics g ) {
		
		g.setColor ( getCouleur() );
		
		g.drawLine ( x, y, x, y );
	}
	
	// Intersections //
	
		// Point - Point //
	
	/**
	 * M�thode d'intersection pr�cise entre un Point et un Point.<br />
	 * Retourne vrai s'il y a collision.
	 * @param p Point.
	 * @return boolean R�sultat du test.
	 */
	public boolean intersection ( Point p ) {
		
		boolean collision = false;
		
		if ( x == p.getX() && y == p.getY() )
			collision = true;
		
		return collision;
	}
	
		// Point - Ligne //
	
	// TODO : travail � faire, si l'envie vous prend :) //
	
		// Point - Rectangle : BoiteEnglobante //
	
		// Point - Ovale //
	
	// TODO : travail � faire, si l'envie vous prend :) //
	
		// Point - Cercle //
	
	/**
	 * M�thode d'intersection pr�cise entre un Point et un Cercle.<br />
	 * Retourne vrai s'il y a collision.
	 * @param c Cercle.
	 * @return boolean R�sultat du test.
	 */
	public boolean intersection ( Cercle c ) {
		
		boolean collision = false;
		
		int dx = x - c.getO().getX();
		int dy = y - c.getO().getY();
		
		if ( ( dx * dx ) + ( dy * dy ) < ( c.getRayon() * c.getRayon() ) )
			collision = true;
		
		return collision;
	}
	
		// Point - Triangle //
	
	// TODO : travail � faire, si l'envie vous prend :) //
}
