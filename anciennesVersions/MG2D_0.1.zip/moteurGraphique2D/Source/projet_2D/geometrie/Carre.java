package projet_2D.geometrie;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Cette classe est un cas particulier qui d�coule de la classe Rectangle.<br />
 * En effet, il s'agit du Carr� qui est un Rectangle particuliers.
 * <br /><br />
 * Elle h�rite de la classe Rectangle afin que toutes les m�thodes de la classe Rectangle s'applique �galement � celle-ci.
 * @author Equipe 2D
 * @version 1.0
 */
public class Carre extends Rectangle {
	
// Constructeurs //

	// Sans couleur //
	
	/**
	 * Construit un Carre � partir d'un autre Carre.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param c Carre.
	 */
	public Carre ( Carre c ) {
		
		super ( c );
	}
	
	/**
	 * Construit un Carre � partir de deux Point.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param a Point min.
	 * @param b Point max.
	 */
	public Carre ( Point a, Point b ) {
		
		super ( a, b );
	}
	
	/**
	 * Construit un Carre plein � partir de deux Point.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param a Point min.
	 * @param b Point max.
	 * @param plein Bool�en.
	 */
	public Carre ( Point a, Point b, boolean plein ) {
		
		super ( a, b, plein );
	}
	
	/**
	 * Construit un Carre dont les bords sont arrondis � partir de deux Points et de deux entiers.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param a Point min.
	 * @param b Point max.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 */
	public Carre ( Point a, Point b, int arcLargeur, int arcHauteur ) {
		
		super ( a, b, arcLargeur, arcHauteur );
	}
	
	/**
	 * Construit un Carre plein dont les bords sont arrondis � partir de deux Points et de deux entiers.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir. 
	 * @param a Point min.
	 * @param b Point max.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 * @param plein Bool�en.
	 */
	public Carre ( Point a, Point b, int arcLargeur, int arcHauteur, boolean plein ) {
		
		super ( a, b, arcLargeur, arcHauteur, plein ); 
	}
	
	/**
	 * Construit un Carre � partir d'un point min et d'un entier correspondant � la dimension des c�t�s.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 */
	public Carre ( Point a, int taille ) {
		
		super ( a, taille, taille );
	}
	
	/**
	 * Construit un Carre plein � partir d'un point min et d'un entier correspondant � la dimension des c�t�s.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 * @param plein Bool�en.
	 */
	public Carre ( Point a, int taille, boolean plein ) {
		
		super ( a, taille, taille, plein );
	}
	
	/**
	 * Construit un Carre dont les bords sont arrondis � partir d'un point min et d'un entier correpsondant � la dimension des c�t�s.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 */
	public Carre ( Point a, int taille, int arcLargeur, int arcHauteur ) {
		
		super ( a, taille, taille, arcLargeur, arcHauteur );
	}
	
	/**
	 * Construit un Carre plein dont les bords sont arrondis � partir d'un point min et d'un entier correspondant � la dimension des c�t�s.<br />
	 * Il s'agit du constructeur sans couleur, ainsi l'objet sera par d�faut en noir.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 * @param plein Bool�en.
	 */
	public Carre ( Point a, int taille, int arcLargeur, int arcHauteur, boolean plein ) {
		
		super ( a, taille, taille, arcLargeur, arcHauteur, plein );
	}
	
	// Avec couleur //
	
	/**
	 * Construit un Carre � partir d'un autre Carre.
	 * @param couleur Couleur de l'objet.
	 * @param c Carre.
	 */
	public Carre ( Color couleur, Carre c ) {
		
		super (	couleur,
				new Point ( c.getA().getX(), c.getA().getY() ),
				new Point ( c.getB().getX(), c.getB().getY() ),
				c.getArcLargeur(),
				c.getArcHauteur(),
				c.getPlein()
		);
	}
	
	/**
	 * Construit un Carre � partir de deux Point et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param b Point max.
	 */
	public Carre ( Color couleur, Point a, Point b ) {
		
		super ( couleur, a, b );
	}
	
	/**
	 * Construit un Carre plein � partir de deux Point et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param b Point max.
	 * @param plein Bool�en.
	 */
	public Carre ( Color couleur, Point a, Point b, boolean plein ) {
		
		super ( couleur, a, b, plein );
	}
	
	/**
	 * Construit un Carre dont les bords sont arrondis � partir de deux Points, de deux entiers et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param b Point max.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 */
	public Carre ( Color couleur, Point a, Point b, int arcLargeur, int arcHauteur ) {
		
		super ( couleur, a, b, arcLargeur, arcHauteur );
	}
	
	/**
	 * Construit un Carre plein dont les bords sont arrondis � partir de deux Points, de deux entiers et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param b Point max.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 * @param plein Bool�en.
	 */
	public Carre ( Color couleur, Point a, Point b, int arcLargeur, int arcHauteur, boolean plein ) {
		
		super ( couleur, a, b, arcLargeur, arcHauteur, plein );
	}
	
	/**
	 * Construit un Carre � partir d'un point min, d'un entier correspondant � la dimension des c�t�s et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 */
	public Carre ( Color couleur, Point a, int taille ) {
		
		super ( couleur, a, taille, taille );
	}
	
	/**
	 * Construit un Carre plein � partir d'un point min, d'un entier correspondant � la dimension des c�t�s et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 * @param plein Bool�en.
	 */
	public Carre ( Color couleur, Point a, int taille, boolean plein ) {
		
		super ( couleur, a, taille, taille, plein );
	}
	
	/**
	 * Construit un Carre dont les bords sont arrondis � partir d'un point min, d'un entier correpsondant � la dimension des c�t�s et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 */
	public Carre ( Color couleur, Point a, int taille, int arcLargeur, int arcHauteur ) {
		
		super ( couleur, a, taille, taille, arcLargeur, arcHauteur );
	}
	
	/**
	 * Construit un Carre plein dont les bords sont arrondis � partir d'un point min, d'un entier correspondant � la dimension des c�t�s et d'une couleur.
	 * @param couleur Couleur de l'objet.
	 * @param a Point min.
	 * @param taille Dimension des c�t�s.
	 * @param arcLargeur Arrondis en largeur.
	 * @param arcHauteur Arrondis en hauteur.
	 * @param plein Bool�en.
	 */
	public Carre ( Color couleur, Point a, int taille, int arcLargeur, int arcHauteur, boolean plein ) {
		
		super ( couleur, a, taille, taille, arcLargeur, arcHauteur, plein );
	}
	
// Accesseurs //

	// Getter //
	
	/**
	 * Retourne l'entier correspondant � la dimension des c�t�s.<br />
	 * Cette valeur est obtenue par un calcul simple : bx - ax.
	 * @return int int correspondant � la dimension des c�t�s.
	 */
	public int getTaille () {
		
		return ( this.getB().getX() - this.getA().getX() );
	}
	
// M�thodes //
	
	/**
	 * Impl�mentation de la m�thode afficher() de la classe abstraite Dessin.<br />
	 * Elle permet d'afficher un Carre sur le Panneau.
	 * <br /><br />
	 * On r�cup�re d'abord la couleur de l'objet afin de le dessiner dans la bonne couleur. Ensuite, on v�rifie si l'objet est arrondis et plein, arrondis ou plein pour appeler les m�thodes ad�quates. Sinon on utilise l'affichage de base avec drawRect().
	 * @param g Graphics.
	 */
	public void afficher ( Graphics g ) {
		
		g.setColor ( getCouleur() );
		
		if ( getArrondis() && getPlein() )
			g.fillRoundRect ( this.getA().getX(), this.getA().getY(), getTaille(), getTaille(), getArcLargeur(), getArcHauteur() );
		
		else if ( getArrondis() )
			g.drawRoundRect ( this.getA().getX(), this.getA().getY(), getTaille(), getTaille(), getArcLargeur(), getArcHauteur() );
		
		else if ( getPlein() )
			g.fillRect ( this.getA().getX(), this.getA().getY(), getTaille(), getTaille() );
		
		else
			g.drawRect ( this.getA().getX(), this.getA().getY(), getTaille(), getTaille() );
	}
}
