package projet_2D.geometrie;

import java.awt.Color;
import java.awt.Graphics;

/**
 * Classe abstraite destin� � repr�senter une forme g�om�trique.
 * <br /><br />
 * Elle permet de g�rer la totalit� des formes g�om�triques du moteur.<br />
 * Chaque classe de Projet_2D g�rant une forme g�om�trique h�rite d'elle.
 * <br /><br />
 * Son seul attribut correspond � la couleur de l'objet. 
 * @author Equipe 2D
 * @version 1.0
 */
public abstract class Dessin {
	
// Attribut //
	
	private Color couleur;
	
// Constructeur //
	
	/**
	 * Construit un Dessin en initialisant sa couleur.
	 * @param couleur Couleur du Dessin.
	 */
	public Dessin ( Color couleur ) {
		
		this.couleur = couleur;
	}
	
// Accesseurs //
	
	// Getter //
	
	/**
	 * Retourne la couleur du Dessin.
	 * @return couleur Couleur du Dessin.
	 */
	public Color getCouleur () {
		
		return couleur;
	}
	
	/**
	 * M�thode abstraite destin�e � retourner la BoiteEnglobante d'un Dessin.<br />
	 * Elle sert � obliger la d�claration d'une m�thode getBoiteEnglobante() dans les diff�rentes classes h�ritant de Dessin.
	 * @return BoiteEnglobante BoiteEnglobante du Dessin
	 */
	public abstract BoiteEnglobante getBoiteEnglobante ();
	
	// Setter //
	
	/**
	 * Attribut une couleur au Dessin.
	 * @param couleur Couleur du Dessin.
	 */
	public void setCouleur ( Color couleur ) {
		
		this.couleur = couleur;
	}
	
// M�thodes //
	
	/**
	 * M�thode abstraite destin�e � afficher un Dessin.<br />
	 * Elle sert � obliger la d�claration d'une m�thode afficher() dans les diff�rentes classes h�ritant de Dessin.
	 * @param g Graphics.
	 */
	public abstract void afficher ( Graphics g );
	
	/**
	 * M�thode de base permettant d'effectuer un test d'intersection via les BoiteEnglobante.<br />
	 * Il s'agit de Polymorphisme destin� � toujours offrir un moyen de tester les intersections � l'utilisateur.
	 * @param d Dessin.
	 * @return boolean Indique s'il y a intersection ou non.
	 */
	public boolean intersection ( Dessin d ) {
		
		return this.getBoiteEnglobante().intersection( d.getBoiteEnglobante() );
	}
	
	/**
	 * Permet de passer outre le polymorphisme.<br />
	 * En appelant cette m�thode, l'utilisateur n'appelle pas les m�thodes d'intersection pr�cise des classes mais celle faisant appel aux BoiteEnglobante.
	 * <br /><br />
	 * Il s'agit donc d'un test d'intersection rapide utilisant toujours les BoiteEnglobante.
	 * @param d Dessin.
	 * @return boolean Indique s'il y a intersection ou non.
	 */
	public boolean intersectionRapide ( Dessin d ) {
		
		return this.getBoiteEnglobante().intersection( d.getBoiteEnglobante() );
	}
}
