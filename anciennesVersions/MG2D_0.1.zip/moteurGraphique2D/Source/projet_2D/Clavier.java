package projet_2D;

import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

/**
 * Cette classe impl�mente les m�thodes de KeyListener permettant la gestion du clavier.
 * <br /><br />
 * A la fa�on d'une borne d'arcade, elle ne g�re uniquement les touches directionnelles, 6 raccourcis, la barre espace et le bouton entr�e.<br />
 * Elle fonctionne sur le principe de bool�en que l'on change quand on appuie ou relache les touches (true quand appuy�, false quand relach�).<br />
 * Si l'utilisateur souhaite impl�menter la gestion de davantages de touches, il peut reprendre ce code et le modifier selon ses besoins.
 * @author Equipe 2D
 * @version 1.0
 */
public class Clavier implements KeyListener {

// Attributs //
	
	private boolean gauche;
	private boolean droite;
	private boolean haut;
	private boolean bas;
	
	private boolean espace;
	private boolean entree;
	
	private boolean a;
	private boolean z;
	private boolean e;
	private boolean q;
	private boolean s;
	private boolean d;
		
// Constructeur //
	
	/**
	 * Construit un Clavier et initialise les attributs � false.
	 */
	public Clavier () {
		
		gauche = droite = haut = bas = false;
		
		espace = entree = false;
		
		a = z = e = q = s = d = false;
	}
	
// Accesseurs //
	
	// Getter //
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche fl�che Gauche.
	 * @return gauche Bool�en correspondant la touche fl�che Gauche.
	 */
	public boolean getGauche () {
		
		return gauche;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche fl�che Droite.
	 * @return gauche Bool�en correspondant la touche fl�che Droite.
	 */
	public boolean getDroite () {
		
		return droite;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche fl�che Haut.
	 * @return gauche Bool�en correspondant la touche fl�che Haut.
	 */
	public boolean getHaut () {
		
		return haut;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche fl�che Bas.
	 * @return gauche Bool�en correspondant la touche fl�che Bas.
	 */
	public boolean getBas () {
		
		return bas;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche Espace.
	 * @return gauche Bool�en correspondant la touche Espace.
	 */
	public boolean getEspace () {
		
		return espace;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche Entr�e.
	 * @return gauche Bool�en correspondant la touche Entr�e.
	 */
	public boolean getEntree () {
		
		return entree;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche A.
	 * @return gauche Bool�en correspondant la touche A.
	 */
	public boolean getA () {
		
		return a;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche Z.
	 * @return gauche Bool�en correspondant la touche Z.
	 */
	public boolean getZ () {
		
		return z;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche E.
	 * @return gauche Bool�en correspondant la touche E.
	 */
	public boolean getE () {
		
		return e;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche Q.
	 * @return gauche Bool�en correspondant la touche Q.
	 */
	public boolean getQ () {
		
		return q;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche S.
	 * @return gauche Bool�en correspondant la touche S.
	 */
	public boolean getS () {
		
		return s;
	}
	
	/**
	 * Retourne la valeur du bool�en correspondant la touche D.
	 * @return gauche Bool�en correspondant la touche D.
	 */
	public boolean getD () {
		
		return d;
	}
		
	// Setter //
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut gauche.
	 * @param gauche Bool�en.
	 */
	public void setGauche ( boolean gauche ) {
		
		this.gauche = gauche;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut droite.
	 * @param droite Bool�en.
	 */
	public void setDroite ( boolean droite ) {
		
		this.droite = droite;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut haut.
	 * @param haut Bool�en.
	 */
	public void setHaut( boolean haut ) {
		
		this.haut = haut;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut bas.
	 * @param bas Bool�en.
	 */
	public void setBas ( boolean bas ) {
		
		this.bas = bas;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut espace.
	 * @param espace Bool�en.
	 */
	public void setEspace ( boolean espace ) {
		
		this.espace = espace;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut entree.
	 * @param entree Bool�en.
	 */
	public void setEntree ( boolean entree ) {
		
		this.entree = entree;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut a.
	 * @param a Bool�en.
	 */
	public void setA ( boolean a ) {
		
		this.a = a;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut z.
	 * @param z Bool�en.
	 */
	public void setZ ( boolean z ) {
		
		this.z = z;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut e.
	 * @param e Bool�en.
	 */
	public void setE ( boolean e ) {
		
		this.e = e;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut q.
	 * @param q Bool�en.
	 */
	public void setQ ( boolean q ) {
		
		this.q = q;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut s.
	 * @param s Bool�en.
	 */
	public void setS ( boolean s ) {
		
		this.s = s;
	}
	
	/**
	 * Permet d'attribuer un bool�en � l'attribut d.
	 * @param d Bool�en.
	 */
	public void setD ( boolean d ) {
		
		this.d = d;
	}
		
// M�thodes //
	
	/**
	 * Impl�mentation de la m�thode KeyReleased.
	 * <br /><br />
	 * Elle permet de mettre � false la valeur des attributs quand l'on relache la touche correspondante.
	 */
	public void keyReleased ( KeyEvent k ) {
		
		switch ( k.getKeyCode() ) {
		
			case KeyEvent.VK_LEFT :
				gauche = false;				
				break;
				
			case KeyEvent.VK_RIGHT :
				droite = false;				
				break;	
				
			case KeyEvent.VK_UP :
				haut = false;
				break;
				
			case KeyEvent.VK_DOWN :
				bas = false;				
				break;
				
			case KeyEvent.VK_SPACE :
				espace = false;			
				break;
			
			case KeyEvent.VK_ENTER :
				entree = false;
				break;
				
			case KeyEvent.VK_A :
				a = false;			
				break;
			
			case KeyEvent.VK_Z :
				z = false;			
				break;
			
			case KeyEvent.VK_E :
				e = false;			
				break;
				
			case KeyEvent.VK_Q :
				q = false;			
				break;
				
			case KeyEvent.VK_S :
				s = false;			
				break;
				
			case KeyEvent.VK_D :
				d = false;			
				break;
		}		
	}
	
	/**
	 * Impl�mentation de la m�thode KeyTyped.
	 * <br /><br />
	 * Cette m�thode est vide car elle ne nous sert pas dans notre moteur.
	 */
	public void keyTyped ( KeyEvent k ) {}
	
	/**
	 * Impl�mentation de la m�thode KeyPressed.
	 * <br /><br />
	 * Elle permet de mettre � true la valeur des attributs quand l'on relache la touche correspondante.
	 */
	public void keyPressed ( KeyEvent k ) {
		
		switch ( k.getKeyCode() ) {
		
			case KeyEvent.VK_LEFT :
				gauche = true;				
				break;
				
			case KeyEvent.VK_RIGHT :
				droite = true;				
				break;	
				
			case KeyEvent.VK_UP :
				haut = true;
				break;
				
			case KeyEvent.VK_DOWN :
				bas = true;				
				break;
				
			case KeyEvent.VK_SPACE :
				espace = true;			
				break;
				
			case KeyEvent.VK_ENTER :
				entree = true;
				break;
				
			case KeyEvent.VK_A :
				a = true;			
				break;
			
			case KeyEvent.VK_Z :
				z = true;			
				break;
			
			case KeyEvent.VK_E :
				e = true;			
				break;
				
			case KeyEvent.VK_Q :
				q = true;			
				break;
				
			case KeyEvent.VK_S :
				s = true;			
				break;
				
			case KeyEvent.VK_D :
				d = true;			
				break;
		}		
	}
}
