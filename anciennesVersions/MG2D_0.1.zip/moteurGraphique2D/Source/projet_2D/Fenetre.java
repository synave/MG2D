package projet_2D;

import projet_2D.geometrie.*;

import java.awt.Dimension;

import javax.swing.JFrame;

/**
 * Cette classe cr��e une JFrame correspondant aux besoins du moteur Projet_2D.
 * <br /><br />
 * L'utilisateur peut d�finir un titre, une largeur et une hauteur � sa fen�tre.<br />
 * Par la suite, il pourra, gr�ce � cette classe, faire le lien entre son programme principal et la classe Panneau g�rant l'affichage des formes.
 * @author Equipe 2D
 * @version 1.0
 */
public class Fenetre extends JFrame {

// Attributs //
	
	private Dimension d;	// Permet de g�rer correctement la dimension du Panneau avec la m�thode p.setPreferredSize ( Dimension ) //
	private Panneau p;

// Constructeur //
	
	/**
	 * Construit une Fenetre poss�dant un titre, une largeur et une hauteur.
	 * <br /><br />
	 * Afin d'avoir un espace de travail de la taille sp�cifi�e par l'utilisateur, la Fenetre sera toujours l�g�rement plus grande que les dimensions donn�es.<br />
	 * Cela permet par exemple de simplifier les calculs de collision avec les bords de la Fenetre puisque l'utilisateur ne devra pas soustraire la taille des bordures.
	 * <br /><br />
	 * Par d�faut, la Fenetre est centr�e et ne peut pas �tre redimensionn�e.
	 * @param titre Titre de la Fenetre.
	 * @param largeur Largeur de l'espace de travail.
	 * @param hauteur Hauteur de l'espace de travail.
	 */
	public Fenetre ( String titre, int largeur, int hauteur ) {
		
		d = new Dimension ( largeur, hauteur );
		p = new Panneau ();
		
		p.setPreferredSize ( d ); // On indique que l'on souhaite avoir un Panneau de la Dimension (largeur, hauteur) //
		
		this.setContentPane ( p );
		
		this.pack(); // Permet d'attribuer automatiquement la dimension de la Fenetre gr�ce � ce qui la compose (ici en l'occurence, le Panneau) //
		
		this.setTitle ( titre );
		
		this.setLocationRelativeTo ( null );
		this.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
		this.setResizable ( false ); // On emp�che le redimensionnement pour �viter les probl�mes de centrages des objets //
		
		this.setVisible ( true );
		
		if ( p.getWidth() > d.getWidth() || p.getHeight() > d.getHeight() ) { // Si le Panneau ne fait toujours pas la taille voulue, on force le changement //
		
			p.setSize ( d );
			this.pack();
		}
	}
	
// Accesseurs //
	
	// Getter //
	
	/**
	 * Retourne le Panneau li� � la Fenetre.
	 * @return p Panneau li� � la Fenetre.
	 */
	public Panneau getP () {
		
		return p;
	}
	
	/**
	 * Permet de faire appel � la m�thode getMilieu() d'un Panneau.
	 * <br /><br />
	 * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
	 * On �vite ainsi � l'utilisateur d'�crire f.getP().getMilieu();
	 * @return Point Point repr�sentant le milieu du Panneau.
	 */
	public Point getMilieu () {
		
		return p.getMilieu();
	}
	
// M�thodes //
	
	/**
	 * Permet d'appliquer la m�thode repaint() � la Fenetre.<br/>
	 * M�thode pr�sente dans un soucis de "Francisation" du code.
	 */
	public void rafraichir () {
		
		repaint();
	}
	
	/**
	 * Permet de faire appel � la m�thode effacer() d'un Panneau.
	 * <br /><br />
	 * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
	 * On �vite ainsi � l'utilisateur d'�crire f.getP().effacer();
	 */
	public void effacer () {
		
		p.effacer();
	}
	
	/**
	 * Permet de faire appel � la m�thode ajouter() d'un Panneau.
	 * <br /><br />
	 * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
	 * On �vite ainsi � l'utilisateur d'�crire f.getP().ajouter();
	 */
	public void ajouter ( Dessin d ) {
		
		p.ajouter ( d );
	}
	
	/**
	 * Permet de faire appel � la m�thode supprimer() d'un Panneau.
	 * <br /><br />
	 * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
	 * On �vite ainsi � l'utilisateur d'�crire f.getP().supprimer();
	 */
	public void supprimer ( Dessin d ) {
		
		p.supprimer ( d );
	}
}
