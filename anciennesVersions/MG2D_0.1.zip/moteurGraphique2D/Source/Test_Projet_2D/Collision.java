import projet_2D.*;
import projet_2D.geometrie.*;

import java.awt.Color;

public class Collision {
	
	public static void main ( String [] args ) {
		
		final int rayon = 50;
		final int largeur = 800;
		final int hauteur = 600;
		
		int dx = 1, dy = 1, cx = 1, cy = 1;
		
		Fenetre f = new Fenetre ( "Projet 2D", largeur, hauteur );
		
		Clavier clavier = new Clavier ();
		
		f.addKeyListener ( clavier );
		
		Point centre = new Point ( 200, 200 );

		Carre k = new Carre ( Color.red, new Point ( 300, 400 ), 100, true );
		
		Cercle c = new Cercle ( Color.green, centre, rayon , true );
		
		f.ajouter ( c );
		f.ajouter ( k );
		
		while ( true ) {
			
			try {
				
				Thread.sleep ( 5 );
			}
			
			catch ( Exception e ) {
				
				System.out.println ( e );
			}
			
			if ( clavier.getGauche() && k.getA().getX() > 0 ) {
				
				k.getA().setX ( k.getA().getX() - 1 );
				k.getB().setX ( k.getB().getX() - 1 );
			}
			
			if ( clavier.getDroite() && k.getB().getX() < largeur ) {
				
				k.getA().setX ( k.getA().getX() + 1 );
				k.getB().setX ( k.getB().getX() + 1 );
			}
			
			if ( clavier.getHaut() && k.getA().getY() > 0 ) {
				
				k.getA().setY ( k.getA().getY() - 1 );
				k.getB().setY ( k.getB().getY() - 1 );
			}
			
			if ( clavier.getBas() && k.getB().getY() < hauteur ) {
				
				k.getA().setY ( k.getA().getY() + 1 );
				k.getB().setY ( k.getB().getY() + 1 );
			}
			
			if ( centre.getX() - rayon == 0 )
				dx = 1;
			
			if ( centre.getX() + rayon == largeur )
				dx = -1;
			
			if ( centre.getY() - rayon == 0 )
				dy = 1;
			
			if ( centre.getY() + rayon == hauteur )
				dy = -1;
			
			if ( c.intersection ( k ) ) {
				
				if ( c.getO().getX() < k.getA().getX() )
					dx = -1;
				
				if ( c.getO().getX() > k.getB().getX() )
					dx = 1;
				
				if ( c.getO().getY() < k.getA().getY() )
					dy = -1;
				
				if ( c.getO().getY() > k.getB().getY() )
					dy = 1;
				
				System.out.println ("Collision : oui" );
			}
			
			centre.setX ( centre.getX() + ( dx * cx ) );
			centre.setY ( centre.getY() + ( dy * cy ) );
					
			f.rafraichir();
		}
	}
}
