import projet_2D.Fenetre;

import projet_2D.geometrie.Cercle;
import projet_2D.geometrie.Point;

import java.awt.Color;

public class Rebond {
	
	public static void main ( String [] args ) {
		
		final int rayon = 100;
		final int largeur = 800;
		final int hauteur = 600;
				
		Fenetre f = new Fenetre ( "Rebond", largeur, hauteur );
		
		int dx = 1, dy = 1;
		
		Point centre = f.getMilieu();
		Cercle c = new Cercle ( Color.green, centre, rayon , true );
				    
		f.ajouter ( c );
		
		while ( true ) {
			
			try {
				
				Thread.sleep ( 5 );
			}
			
			catch ( Exception e ) {
				
				System.out.println ( e );
			}
						
			if ( centre.getX() - rayon == 0 )
				dx = 1;
			
			if ( centre.getX() + rayon == largeur )
				dx = -1;
			
			if ( centre.getY() - rayon == 0 )
				dy = 1;
			
			if ( centre.getY() + rayon == hauteur )
				dy = -1;
			
			centre.setX ( centre.getX() + dx );
			centre.setY ( centre.getY() + dy );

			f.rafraichir();
		}
	}	
}
