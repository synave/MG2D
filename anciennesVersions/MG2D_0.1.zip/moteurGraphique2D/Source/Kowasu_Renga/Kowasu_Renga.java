import projet_2D.Fenetre;

import projet_2D.geometrie.Cercle;
import projet_2D.geometrie.Point;
import projet_2D.geometrie.Rectangle;
import projet_2D.geometrie.Texture;

import java.awt.Color;

public class Kowasu_Renga {

// Attributs //
	
	final static int largeur = 840;
	final static int hauteur = 900;
	
	static Fenetre f = new Fenetre ( "Kowasu Renga", largeur, hauteur );
	
	private static Point a = new Point ( ( largeur / 2 ) - 40, hauteur - 40 );
	private static Point b = new Point ( ( largeur / 2 ) + 40, hauteur - 30 );
	
	private static int cx = 1;
	private static int cy = 1;
	
	private static Clavier clavier = new Clavier ();
	
	// G�ometrie //
	
	private static Texture background = new Texture ( "img/background.jpg", new Point ( 0, 0 ) );
	
	private static Rectangle joueur = new Rectangle ( Color.white, a, b, true );
	
	private static Point centre = new Point ( f.getMilieu().getX(), hauteur - 51 );	
	private static Cercle balle = new Cercle ( Color.white, centre, 8, true );
	
// Main //	
	
	public static void main ( String [] args ) {
		
		f.ajouter ( background );
		f.ajouter ( joueur );		
		f.ajouter ( balle );
		
		f.addKeyListener ( clavier );
		
		int c = 0;	// Pour varier les couleurs //
		int z = 0;	// Incr�mente le tableau de rectangle //
		int nb = 5;	// Nombre de coup n�cessaire pour casser un bloc //
		
		Color [] couleur = {
		
			new Color ( 103, 11, 122 ),		// Violet //
			new Color ( 12, 73, 156 ),		// Bleu fonc� //
			new Color ( 106, 204, 229 ),	// Bleu clair //
			new Color ( 121, 160, 5 ),		// Vert //
			new Color ( 250, 241, 24 )		// Jaune //
		};
		
		Rectangle [] bloc = new Rectangle[50];
		int [][] info_bloc = new int [50][3];	// Information sur les blocs : l'�tat du bloc, le nombre de coups pour le d�truire et l'indice de la couleur utilis�e //
		
		for ( int i = 200; i < 450; i += 50 ) {
			
			for ( int j = 30; j < 830; j += 80 ) {
				
				bloc [z] = new Rectangle ( couleur [c], new Point ( j, i ), 68, 38, true );
				
				info_bloc [z][0] = 1;
				info_bloc [z][1] = nb;
				info_bloc [z][2] = c;
				
				f.ajouter ( bloc [z] );
				
				z++;
			}
			
			c++;
			nb--;
		}
		
		Texture [] score_nb = {
			
			new Texture ( "img/0.png", new Point ( largeur - 32, 10 ) ),
			new Texture ( "img/0.png", new Point ( largeur - 64, 10 ) ),
			new Texture ( "img/0.png", new Point ( largeur - 96, 10 ) ),
			new Texture ( "img/0.png", new Point ( largeur - 128, 10 ) ),
			new Texture ( "img/0.png", new Point ( largeur - 160, 10 ) )
		};
		
		f.ajouter ( score_nb[0] );
		f.ajouter ( score_nb[1] );
		f.ajouter ( score_nb[2] );
		f.ajouter ( score_nb[3] );
		f.ajouter ( score_nb[4] );
		
		int vitesse = 6;	// Permet de faire varier la vitesse du jeu //
		int score = 0;		// Repr�sente le score du joueur //

		nb = 0;				// Correspond au nombre de fois que l'on touche un bloc, sert � augmenter d�cider quand on augmente la vitesse //
		
		while ( true ) {
			
			try {
				
				Thread.sleep ( vitesse );
			}
			
			catch ( Exception e ) {
				
				System.out.println ( e );
			}
			
			if ( clavier.getGauche() ) {
				
				if ( a.getX() > 0 ) {
					
					if ( clavier.getDx() == 0 && clavier.getDy() == 0 )
						centre.setX ( centre.getX() - 3 );

					a.setX ( a.getX() - 3 );
					b.setX ( b.getX() - 3 );
				}
			}
			
			if ( clavier.getDroite() ) {
				
				if ( b.getX() < largeur ) {
					
					if ( clavier.getDx() == 0 && clavier.getDy() == 0 )
						centre.setX ( centre.getX() + 3 );
					
					a.setX ( a.getX() + 3 );
					b.setX ( b.getX() + 3 );
				}
			}
						
			if ( centre.getX() - 10 == 0 )
				clavier.setDx ( 1 );
			
			if ( centre.getY() - 10 == 0 )
				clavier.setDy ( 1 );
			
			if ( centre.getX() + 10 == largeur )
				clavier.setDx ( -1 );
			
			if ( centre.getY() + 10 == hauteur ) {		// La balle est perdue, on reset les param�tres //
			
				clavier.setDx ( 0 );
				clavier.setDy ( 0 );
				
				a.setX ( ( largeur / 2 ) - 40 );
				b.setX ( ( largeur / 2 ) + 40 );
				
				centre.setX ( f.getMilieu().getX() );
				centre.setY ( hauteur - 51 );
				
				vitesse = 6;
			}
			
			if ( balle.intersectionRapide ( joueur ) ) {
				
				if ( balle.getO().getX() < joueur.getA().getX() )
					clavier.setDx ( -1 );
				
				if ( balle.getO().getY() < joueur.getA().getY() )
					clavier.setDy ( -1 );
				
				if ( balle.getO().getX() > joueur.getB().getX() )
					clavier.setDx ( 1 );
				
				if ( balle.getO().getY() > joueur.getB().getY() )
					clavier.setDy ( 1 );
			}
			
			for ( int i = 0; i < 50; i++ ) {		// Test si il y a collision avec les blocs //
			
				if ( balle.intersectionRapide ( bloc [i] ) && info_bloc [i][0] == 1 ) {
					
					if ( balle.getO().getX() < bloc[i].getA().getX() )
						clavier.setDx ( -1 );
					
					if ( balle.getO().getY() < bloc[i].getA().getY() )
						clavier.setDy ( -1 );
					
					if ( balle.getO().getX() > bloc[i].getB().getX() )
						clavier.setDx ( 1 );				
					
					if ( balle.getO().getY() > bloc[i].getB().getY() )
						clavier.setDy ( 1 );
					
					if ( info_bloc[i][1] == 1 ) {	// Si le bloc est d�truit //
					
						f.supprimer ( bloc [i] );		// On le supprime de l'affichage //
						
						info_bloc [i][0] = 0;
						
						score += 100;
					} 
					
					else {	// Sinon on fragilise le bloc //
					
						info_bloc[i][1]--;	// On r�duit le nombre de coups restant //
						info_bloc[i][2]++;	// On lui change sa couleur //
						
						bloc[i].setCouleur ( couleur [info_bloc[i][2]] );
						score += 10;
					}
					
					nb++;

					if ( vitesse > 2 ) {
						
						if ( nb == 10 ) {
							
							vitesse--;
							nb = 0;
						}
					}
					
					int s = score / 10;
					int y = 1;
					
					while ( s != 0 ) {
						
						int mod = s % 10;
						s /= 10;
						
						score_nb[y].setImg ( "img/" + mod + ".png" );
						y++;
					}
				}
			}
			
			centre.setX ( centre.getX() + ( clavier.getDx() * cx ) );
			centre.setY ( centre.getY() + ( clavier.getDy() * cy ) );
					
			f.rafraichir();
		}
	}	
}