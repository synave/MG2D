import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Clavier implements KeyListener {
	
// Attributs //
	
	private int dx;
	private int dy;
	
	private boolean gauche;
	private boolean droite;
	
// Constructeur //
	
	public Clavier () {
		
		dx = dy = 0;
		gauche = droite = false;
	}
	
// Accesseurs //
	
	// Getter //
	
	public int getDx () {
		
		return dx;
	}
	public int getDy () {
		
		return dy;
	}
	
	public boolean getGauche () {
		
		return gauche;
	}
	public boolean getDroite () {
		
		return droite;
	}
	
	// Setter //
	
	public void setDx ( int dx ) {
	
		this.dx = dx;
	}
	public void setDy ( int dy ) {
		
		this.dy = dy;
	}
	
	public void setGauche ( boolean gauche ) {
		
		this.gauche = gauche;
	}
	public void setDroite ( boolean droite ) {
		
		this.droite = droite;
	}
	
// M�thodes //
	
	public void keyReleased ( KeyEvent e ) {
		
		switch ( e.getKeyCode() ) {
			
			case KeyEvent.VK_SPACE :
				if ( dx == 0 && dy == 0 ) {
					
					dx = -1;
					dy = -1;
				}
			
				break;
			
			case KeyEvent.VK_LEFT :
				gauche = false;
				break;
			
			case KeyEvent.VK_RIGHT :
				droite = false;
				break;	
		}
	}
	
	public void keyPressed ( KeyEvent e ) {
		
		switch ( e.getKeyCode() ) {
			
			case KeyEvent.VK_LEFT :
				gauche = true;
				break;
				
			case KeyEvent.VK_RIGHT :
				droite = true;
				break;	
		}
	}

	public void keyTyped ( KeyEvent e ) {}
}
