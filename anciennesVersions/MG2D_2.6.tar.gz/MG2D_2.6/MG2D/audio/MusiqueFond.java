package MG2D.audio;

import java.io.File;
import java.io.FileInputStream;


import javazoom.jl.player.advanced.AdvancedPlayer;
import javazoom.jl.player.advanced.PlaybackListener;
import javazoom.jl.player.advanced.PlaybackEvent;

// TODO - ne faire que des méthodes static
// MusiqueFond.jouer(".../mp3");
// MusiqueFond.stop();
// Roh que c'est mal codé...

/**
 * Cette classe permet la lecture d'une musique en boucle. Il est impossible d'en changer ni de l'arrêter. Faites donc bien attention avant de la lancer !<br />
 * Cette classe sera réécrite d'ici peu. (avant 2025).
 */


public class MusiqueFond extends Thread {

    private static String fichier="";
    private static int nbConfig=0;
    private static Thread enCours=null;
    private AdvancedPlayer player;

    /**
     * Permet de créer le morceau de musique qui sera joué en boucle.<br />
     * Attention, ne fonctionne qu'avec des fichiers mp3.<br />
     * Pour lancer la musique, il faut appeler la méthode lecture.
     * @param fic Le chemin vers le fichier de la musique.
     */
    public MusiqueFond(String fic) throws java.lang.RuntimeException{
	try{
	    if(fichier.equals(fic) || nbConfig==0){
		if(nbConfig==0){
		    enCours=this;
		    fichier=new String(fic);
		    nbConfig++;
		}
		FileInputStream fis = new FileInputStream(fichier);
		player = new AdvancedPlayer(fis);
		
		player.setPlayBackListener(new PlaybackListener(){
			
			
			//override unimplemented methods
			@Override
			public void playbackFinished(PlaybackEvent evt){
			    try{
				MusiqueFond m = new MusiqueFond(fichier);
				enCours=m;
				m.lecture();
				arret();
			    }
			    catch(Exception ex){} 
			}
			
			@Override
			public void playbackStarted(PlaybackEvent evt){
			}
		    });
	    }
	    else{
		System.out.println("Impossible de lancer deux musiques de fond différentes.");
	    }
	}
	catch(Exception ex){}
    }
    
    /**
     * Lance la lecture de la musique de fond.
     */
    public void lecture(){
	start();
    }

    /**
     * Ne fonctionne pas.
     */
    public void arret(){
	// Ne fonctionne pas. Ca ne sert à rien de tester
	// puisque je vous dis que ça ne fonctionne pas !
	// Peut être pour la prochaine version de MG2D...
	stop();
    }
	
    @Override
    public void run() {
	try{
	    player.play();
	}
	catch(Exception ex){}
	player.close();
	//stop();
    }

	
}
