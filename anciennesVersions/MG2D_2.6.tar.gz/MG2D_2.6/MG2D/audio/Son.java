package MG2D.audio;

import java.io.File;
import java.io.FileInputStream;

import javazoom.jl.player.Player;

/**
 * Cette classe permet la lecture d'un son, un bruitage ou une musique une fois. Pour jouer plusieurs fois le même son, il faudra instancier autant d'objets que de fois à lire le son.<br />
 * Cette classe sera réécrite d'ici peu. (avant 2025).
 */

public class Son extends Thread {

    private Player player;
    
    /**
     * Permet de créer le son qui sera joué.<br />
     * Attention, ne fonctionne qu'avec des fichiers mp3.<br />
     * Pour lancer le son, il faut appeler la méthode lecture.
     * @param fic Le chemin vers le fichier de la musique.
     */
    public Son(String fic){
	try{  
	    FileInputStream fis = new FileInputStream(fic);
	    player = new Player(fis);
	}
	catch(Exception ex){}
    }

    /**
     * Lance la lecture du son.
     */
    
    public void lecture(){
	start();
    }

    /**
     * Arrête peut-être le son en cours. Pas sûr, ça n'a pas été testé.
     */
    public void arret(){
	player.close();
	stop();
    }
	
    @Override
    public void run() {
	try{
	    player.play();
	}
	catch(Exception ex){}
	player.close();
	stop();
    }

	
}
