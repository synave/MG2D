
	                         ''~``
	                        ( o o )
	+------------------.oooO--(_)--Oooo.------------------+
	|                                                     |
	|			Projet 2D		      |
	|	    Moteur graphique 2D minimaliste	      |
	|						      |
	+-----------------------------------------------------+
	|						      |
	| C'est désormais terminé, la deadline est atteinte ! |
	|						      |
	| Après plusieurs mois de codage intensif, nous voilà |
	| enfin au moment de lancer notre moteur dans le      |
	| monde sauvage de la notation ... :'(		      |
	|						      |
	| C'est avec plaisir que l'Equipe 2D vous fournit ce  |
	| .zip et espère que vous passerez de bons moments à  |
	| programmer de petits jeux rétro !		      |
	|						      |
	+-----------------------------------------------------+
	|						      |
	| Projet 2D					      |
	| Version 2.6					      |
	| 10 Avril 2017   				      |
	|						      |
	| Développé par :				      |
	|   - Anthony Desitter				      |
	|   - Nicolas Dubrunfaut			      |
	|   - Maxime Langa				      |
	|   - Guillaume Langa				      |
	|						      |
	|   - Rémi Synave				      |
	|						      |
	+-----------------------------------------------------+
	|						      |
	| Les sources sont disponibles dans le dossier Source.|
	|						      |
	| Les jeux sont disponibles dans les dossiers :       |
	|   - Kowasu Renga (casse-brique)		      |
	|   - Snake Eater (snake)			      |
	|   - Pong (avec du son)			      |
	|						      |
	| Le dossier Test_MG2D contient tous les tests        |
	| relatifs au moteur MG2D.			      |
	|						      |
	+-----------------------------------------------------+
	|						      |
	| Nous tenons à remercier M. Synave, notre tuteur,    |
	| pour ses nombreux conseils et son aide précieuse    |
	| sans laquelle ce projet n'en serait pas arrivé là.  |
	|						      |
	| En espérant que vous apprécierez notre petite	      |
	| surprise plus bas :)				      |
	|						      |
	|                    .oooO                            |
	|                    (   )   Oooo.                    |
	+---------------------\ (----(   )--------------------+
		               \_)    ) /
	                             (_/









                                     _____
                                 .-~~     ~~~~--......___
                                <  |-.                   ~~--._
                                |  |  ~T-....______     ______ `.
                                |  |   |       .   ~~~~~      ~~~
                                |  |   `.     /    -~~-.
                                |  |  . |   .'    '             /`.
                                :  |  | |   |    '            ,' ,.`.
                                \  |  | /   | ,''            / ,' \  ~-.
                                 \  . |`-~~--L |.--.       ,'     /.   `
                          ____  ,'\ >  .~.'   ~`'   `~-.  /   ,  / >    `.
                        /~   _\/   `' '  |           .  \/  ,' .'.~,\    `.
                       /   ,d#b    / '   |           `     '.-~~~,'  >    `m.
                       \  m####b  | '    `            |    ~~~~-<  ,d#.    "##
                     ,-~' ######b ||   |  `           `          \d"d#b      Y
                      ~:  #######b|:   `\  `         ` :          "d###b      .
                       | d########b\    \\  `.        :|           "####b     :
                       ' ##########b     \`-.  .      |`.:          "####b     .
                      ;  ###########\     `--`=`.\     .||          |#####b    |
                     :   ###########b\ :      __  .   '|;|      \   d######\   |
                      \.'############/.`   .-~ \-.|  /./,'      .' d######P `  |
                       ; ###########P | \  ;,b `~|; /,'~`      ,',d######P   | |
                      < :"#########P  '  : \ /.  |,' T~|/ , +-~ db"#####P    | |
                       ~| ########P ,'   '  `-'  ~   P ; /  |  d#######P      \|
                         ~`#####P' /    /           <'  <   `~""######P
                           `###P ,'    <          `.`- / ;  |    "###P..
                        __  "#P /     / \      ._ /   | .   `.    ##P__ ~7~
                     .-~  ~--~\/    ,'/ ,`     | '   _| |     \ -_ P~  ~-'
                    '~\_.-~~7\/    / |L/. `.   `'  .-`  |`.   \`.  ~~~.
                      ~    / |    .| '|-/   `.  .-~\  \\ \_`-. \`  \`.|
                          /  /`.  |_\\\_\.-...~~<__.\  \`-.~~ `-|   | \
                         '~., ##m##"      \  oo. .'  `.~~T~ ~~~/:-. | |
                           |  ###P   .'   |_|88)mmmm'-~  |    / | | /,'
                              ##"    :   dd##>"""####b~-. .  /  | ;-
                              |      :  d###P     ~"~~   > `<  ,'/
                              |      `./"#P~        |   /    \  ~
                              |       /  |          ;  /      |
                              `      /   |      |     .       |
                               \    /    |      |  :  '       '
                                \  ; /`.  \     \  ','       ,
                                 \| '   `.  \  | `./        .
                                  |/      `--._;_ /   ._ _.+'
                                  |             /`-..   ~  |
                                   \           |   ,'      |
                                    `.          \,'/       |
                                      `._      ,' /        |
         _...---.._                     \.       /_        |
       ,'          ~~"--..                ~     /~ ~-_     ;
      /                   ~"-._            \   /      T.  .
     /                         ~-.         |  /       `8bd8
    /              .              `-.      | '         8888
    \             -.\                `-.    '`.        8888b
     \              ~-.                 `-.   |   :   d8888P\
  ,-~~\                ~.                  `. |   ;  d8888P  \
 /     \                 `.                 .~'.    d8888P    \   _.,_
.       \                  `.               `.  `. d8888P      \-~  ~ ~-.
|        \                   .               |    <8888P        \        ~-.
|         \                   \              |     \88P .        \         |
 .         `.                  \             |     |`P-~          .        \
             \                  \            |     |              |        .'
  `           `.                 \           |     |              |        >
   `           \.                 \          |     |              |        '
    `           \`.                \         '     |              ;       ~;
     .           \ -.               \       '      '             .        /
     `               -.              \     '      :              ;      /~
      .           `    -              \  .'       '             .~-.  /~
      `            \    ~-             \~        /              ;   ~~
       `            .     ~.            \     _-~              /
        .            \      -_           \  .-                /
        `                    _-           \~                .'
         .            |`.---~  ~.          \              _-
         `            |  `.___.-~\          \         _.-~
          .           |    `.     \          \~-.__.-~
          `           |      `-.   `.         \
           `          `         ~~---\         \
            .          .              `.        `.
            `          :                \         `.
             \         `                 \          `.
              \         .                 `.         `~~-.
               \        :                   `         \   \
                .        .                   \         : `.\
                `        :                    \        |  | .
                 \        .                    \       |  |
                  \       :                     \      `  |  `
                   .                             .      | |_  .
                   `       `.                    `      ` | ~.;
                    \       `.                    .      . .
                     .       `.                   `      ` `
                     `.       `._.                 \      `.\
                      `        <  \                 `.     | .
                       `       `   :                 `     | |
                        `       \                     `    | |
                         `.     |   \                  :  .' |
 "Super-Idol Misty May"   `     |    \                 `_-'  |
   (from "Otaku no         :    | |   |                 :    ;
     Video [1985]")        `    ; |~-.|                 :    '
     --- Dov Sherman        :   \ |                     `   ,
                            `    \`                      :  '
                             :    \`                     `_/
                             `     .\
                              `    ` \
                               \    | :
                                \  .'  :
                                 T~    :
                                 |    .'
                                 |    :
                                 |    '
                                 |   /
                                 `_.'
