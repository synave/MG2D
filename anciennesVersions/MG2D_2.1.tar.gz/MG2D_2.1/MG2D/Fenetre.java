package MG2D;

import MG2D.geometrie.*;

import java.awt.Dimension;

import javax.swing.JFrame;

import java.awt.Robot;
import java.util.Calendar;
import java.util.Date;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Cette classe créée une JFrame correspondant aux besoins du moteur MG2D.
 * <br /><br />
 * L'utilisateur peut définir un titre, une largeur et une hauteur à sa fenêtre.<br />
 * Par la suite, il pourra, grâce à cette classe, faire le lien entre son programme principal et la classe Panneau gérant l'affichage des formes.
 * @author Equipe 2D
 * @version 2.0
 */
public class Fenetre extends JFrame {

    // Attributs //
	
    private Dimension d;	// Permet de gérer correctement la dimension du Panneau avec la méthode p.setPreferredSize ( Dimension ) //
    private Panneau p;

    //Pour la gestion d'un clavier et d'une souris classique. Attributs qui ne seront pas forcément instanciés.
    private Clavier c;
    private Souris s;

    //Pour le calcul des fps
    private long dernierEvt;
    private long dernierAffichage;
    private boolean affichageFPS;

    String titre;

    // Constructeur //

    /**
     * Construit une Fenetre ayant une zone d'affichage de 800x600 pixels et de titre "Mon appli MG2D.
     * <br /><br />
     * Par défaut, la Fenetre est centrée et ne peut pas être redimensionnée.
     */
    public Fenetre () {

	//Non instanciation du clavier et de la souris
	c=null;
	s=null;
	
	d = new Dimension ( 800, 600 );
	p = new Panneau ();
		
	p.setPreferredSize ( d ); // On indique que l'on souhaite avoir un Panneau de la Dimension (largeur, hauteur) //
		
	this.setContentPane ( p );
		
	this.pack(); // Permet d'attribuer automatiquement la dimension de la Fenetre grâce à ce qui la compose (ici en l'occurence, le Panneau) //
		
	this.setTitle ( new String("Mon appli MG2D") );
	titre=new String("Mon appli MG2D");
		
	this.setLocationRelativeTo ( null );
	this.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
	this.setResizable ( false ); // On empêche le redimensionnement pour éviter les problèmes de centrages des objets //
		
	this.setVisible ( true );
		
	if ( p.getWidth() != d.getWidth() || p.getHeight() != d.getHeight() ) { // Si le Panneau ne fait toujours pas la taille voulue, on force le changement //
		
	    p.setSize ( d );
	    p.setMinimumSize( d );
	    p.setMaximumSize( d );
	    this.pack();
	    // Je ne comprends pas pourquoi ces 2 lignes sont nécessaires mais il ne faut pas les enlever !
	    revalidate();
	    pack();
	}
	dernierEvt = new Date().getTime();
	affichageFPS=false;
	dernierAffichage=dernierEvt;
    }
	
    /**
     * Construit une Fenetre possédant un titre, une largeur et une hauteur.
     * <br /><br />
     * Attention, la taille précisé en paramètre correspond à la taille de la zone d'affichage. La taille de la fenêtre sera légérement plus grande.<br />
     * <br /><br />
     * Par défaut, la Fenetre est centrée et ne peut pas être redimensionnée.
     * @param ttitre Titre de la Fenetre.
     * @param largeur Largeur de l'espace de travail.
     * @param hauteur Hauteur de l'espace de travail.
     */
    public Fenetre ( String ttitre, int largeur, int hauteur ) {

	//Non instanciation du clavier et de la souris
	c=null;
	s=null;
	
	d = new Dimension ( largeur, hauteur );
	p = new Panneau ();
		
	p.setPreferredSize ( d ); // On indique que l'on souhaite avoir un Panneau de la Dimension (largeur, hauteur) //
		
	this.setContentPane ( p );
		
	this.pack(); // Permet d'attribuer automatiquement la dimension de la Fenetre grâce à ce qui la compose (ici en l'occurence, le Panneau) //
		
	this.setTitle ( new String(ttitre) );
	titre=new String(ttitre);
		
	this.setLocationRelativeTo ( null );
	this.setDefaultCloseOperation ( JFrame.EXIT_ON_CLOSE );
	this.setResizable ( false ); // On empêche le redimensionnement pour éviter les problèmes de centrages des objets //
		
	this.setVisible ( true );
		
	if ( p.getWidth() != d.getWidth() || p.getHeight() != d.getHeight() ) { // Si le Panneau ne fait toujours pas la taille voulue, on force le changement //
		
	    p.setSize ( d );
	    p.setMinimumSize( d );
	    p.setMaximumSize( d );
	    this.pack();
	    // Je ne comprends pas pourquoi ces 2 lignes sont nécessaires mais il ne faut pas les enlever !
	    revalidate();
	    pack();
	}
	dernierEvt = new Date().getTime();
	affichageFPS=false;
	dernierAffichage=dernierEvt;
    }
	
    // Accesseurs //
	
    // Getter //
	
    /**
     * Retourne une copie du Panneau lié à la Fenetre.
     * @return copie du Panneau lié à la Fenetre.
     */
    public Panneau getP () {
		
	return new Panneau(p);
    }

    /**
     * Retourne un clavier par défaut. Permet une gestion des touches par le clavier prédéfini dans la bibliothèque.
     * @return Un clavier classique.
     */
    public Clavier getClavier () {
	
	c = new Clavier();
	addKeyListener(c);
	return c;
    }

    /**
     * Retourne un clavier par défaut. Permet une gestion des touches par le clavier prédéfini dans la bibliothèque.
     * @return Un clavier classique.
     */
    public Souris getSouris () {
	
	s = new Souris((int)(d.getHeight()));
	addMouseListener(s);addMouseMotionListener(s);
	p.addMouseListener(s);p.addMouseMotionListener(s);
	return s;
    }
	
    /**
     * Permet de faire appel à la méthode getMilieu() d'un Panneau.
     * <br /><br />
     * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
     * On évite ainsi à l'utilisateur d'écrire f.getP().getMilieu();
     * @return Point Point représentant le milieu du Panneau.
     */
    public Point getMilieu () {
		
	// p.getMilieu retourne déjà un "new Point"
	return p.getMilieu();
    }

    /**
     * Permet de spécifier si l'affichage des FPS doit se faire ou non.
     */
    public void setAffichageFPS(boolean b){
	affichageFPS=b;
	if(b==false)
	    setTitle(titre);
    }
	
    // Méthodes //
	
    /**
     * Permet d'appliquer la méthode repaint() à la Fenetre.<br/>
     * Méthode présente dans un soucis de "Francisation" du code.
     */
    public void rafraichir () {
	long temp=new Date().getTime();
	double fps = 1000.0/(temp-dernierEvt);
	if(affichageFPS && ((temp-dernierAffichage)>1000)){
	    setTitle(titre+" - "+fps+" fps");
	    dernierAffichage=temp;
	}
	dernierEvt=temp;
	repaint();
    }
	
    /**
     * Permet de faire appel à la méthode effacer() d'un Panneau.
     * <br /><br />
     * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
     * On évite ainsi à l'utilisateur d'écrire f.getP().effacer();
     */
    public void effacer () {
		
	p.effacer();
    }
	
    /**
     * Permet de faire appel à la méthode ajouter() d'un Panneau.
     * <br /><br />
     * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
     * On évite ainsi à l'utilisateur d'écrire f.getP().ajouter();
     */
    public void ajouter ( Dessin d ) {
		
	p.ajouter ( d );
    }
	
    /**
     * Permet de faire appel à la méthode supprimer() d'un Panneau.
     * <br /><br />
     * Il s'agit simplement d'un relais entre le programme principal et la classe Panneau.<br />
     * On évite ainsi à l'utilisateur d'écrire f.getP().supprimer();
     */
    public void supprimer ( Dessin d ) {
		
	p.supprimer ( d );
    }
    
    /**
     * Permet de faire un screenshot de la fenetre.
     * <br /><br />
     * L'image sera créé dans le répertoire courant et aura la date du jour pour nom.
     */
    public void snapShot(){
	try{
	    Robot rb = new Robot();
	    Calendar cal=Calendar.getInstance();
	    String chemin=new String(cal.get(cal.YEAR)+"_" +(cal.get(cal.MONTH)+1)+"_"+cal.get(cal.DAY_OF_MONTH)+"__"+cal.get(cal.HOUR_OF_DAY)+"_"+cal.get(cal.MINUTE)+"_"+cal.get(cal.SECOND)+".jpg");
	    BufferedImage bufImage = rb.createScreenCapture(new java.awt.Rectangle(getX(),getY(),getWidth(),getHeight()));
	    File imageFile = new File(chemin);
	    imageFile.createNewFile();
	    ImageIO.write(bufImage, "jpeg", imageFile);
	}
	catch(Exception e){
	    System.out.println(e);
	}
    }

    /**
     * Permet de faire un screenshot de la fenetre.
     * <br /><br />
     * L'image sera créé à l'endroit fixé par le paramètre.
     */
    public void snapShot(String chemin){
	try{
	    Robot rb = new Robot();
	    BufferedImage bufImage = rb.createScreenCapture(new java.awt.Rectangle(getX(),getY(),getWidth(),getHeight()));
	    File imageFile = new File(chemin);
	    imageFile.createNewFile();
	    ImageIO.write(bufImage, "jpeg", imageFile);
	}
	catch(Exception e){
	    System.out.println(e);
	}
    }

    /**
     * Méthode toString.
     */
    public String toString(){
	return new String("Fenêtre de taille "+d.getWidth()+"x"+d.getHeight());
    }
}
