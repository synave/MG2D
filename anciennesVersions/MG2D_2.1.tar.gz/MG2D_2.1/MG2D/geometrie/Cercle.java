package MG2D.geometrie;


import java.awt.Graphics;

/**
 * Cette classe est un cas particulier qui découle de la classe Ovale.<br />
 * En effet, il s'agit du Cercle qui est un Ovale particuliers.
 * <br /><br />
 * Elle hérite de la classe Ovale afin que toutes les méthodes de la classe Ovale s'applique également à celle-ci.
 * @author Equipe 2D
 * @version 2.0
 */
public class Cercle extends Ovale {
	
    // Attribut //

    // Constructeur //

    /**
     * Construit un cercle noir centré en (1,1) et de rayon 1.
     */
    public Cercle(){
	super(new Point(1,1),2,2);
    }

    // Sans couleur //
	
    /**
     * Construit un Cercle à partir d'un Cercle.<br />
     * Il s'agit du constructeur sans couleur, ainsi l'objet sera par défaut en noir.
     * @param c Cercle.
     */
    public Cercle ( Cercle c ) {
		
	super ( c.getO(),
		c.getDiametre(),
		c.getDiametre(),
		c.getPlein()
		);
    }

    /**
     * Construit un Cercle à partir d'un Point et d'un rayon.<br />
     * Il s'agit du constructeur sans couleur, ainsi l'objet sera par défaut en noir.
     * @param o Point correspondant au centre du Cercle.
     * @param rayon int correspondant au rayon du Cercle.
     */
    public Cercle ( Point o, int rayon ) {
		
	super ( o, rayon*2, rayon*2 );
    }
	
    /**
     * Construit un Cercle plein à partir d'un Point et d'un rayon.<br />
     * Il s'agit du constructeur sans couleur, ainsi l'objet sera par défaut en noir.
     * @param o Point correspondant au centre du Cercle.
     * @param rayon int correspondant au rayon du Cercle.
     * @param plein Booléen.
     */
    public Cercle ( Point o, int rayon, boolean plein ) {
		
	super ( o, rayon*2, rayon*2, plein );

    }
	
    /**
     * Construit un Cercle à partir d'un Carre.<br />
     * Il s'agit du constructeur sans couleur, ainsi l'objet sera par défaut en noir.
     * <br /><br />
     * Le centre du cercle sera obtenue via les coordonnées du Point min du Carre auxquelles on ajoute la moitié de la dimension des côtés.
     * @param c Carre qui définie le Cercle.
     */
    public Cercle ( Carre c ) {
		
	super ( new Point ( ( c.getA().getX() + c.getTaille() / 2 ), ( c.getA().getY() + c.getTaille() / 2 ) ),
		c.getTaille(),
		c.getTaille()
		);
    }
	
    /**
     * Construit un Cercle plein à partir d'un Carre.<br />
     * Il s'agit du constructeur sans couleur, ainsi l'objet sera par défaut en noir.
     * <br /><br />
     * Le centre du cercle sera obtenue via les coordonnées du Point min du Carre auxquelles on ajoute la moitié de la dimension des côtés.
     * @param c Carre qui définie le Cercle.
     * @param plein Booléen.
     */
    public Cercle ( Carre c, boolean plein ) {
		
	super ( new Point ( ( c.getA().getX() + c.getTaille() / 2 ), ( c.getA().getY() + c.getTaille() / 2 ) ),
		c.getTaille(),
		c.getTaille(),
		plein
		);
    }
	
    // Avec couleur //
	
    /**
     * Construit un Cercle à partir d'un Cercle.
     * @param couleur Couleur de l'objet.
     * @param c Cercle.
     */
    public Cercle ( Couleur couleur, Cercle c ) {
		
	super ( couleur,
		c.getO(),
		c.getDiametre(),
		c.getDiametre(),
		c.getPlein()
		);
    }
	
    /**
     * Construit un Cercle à partir d'un Point, d'un rayon et d'une couleur.<br />
     * @param couleur Couleur de l'objet.
     * @param o Point correspondant au centre du Cercle.
     * @param rayon int correspondant au rayon du Cercle.
     */
    public Cercle ( Couleur couleur, Point o, int rayon ) {
		
	super ( couleur, o, rayon*2, rayon*2 );
    }
	
    /**
     * Construit un Cercle plein à partir d'un Point, d'un rayon et d'une couleur.<br />
     * @param couleur Couleur de l'objet.
     * @param o Point correspondant au centre du Cercle.
     * @param rayon int correspondant au rayon du Cercle.
     * @param plein Booléen.
     */
    public Cercle ( Couleur couleur, Point o, int rayon, boolean plein ) {
		
	super ( couleur, o, rayon*2, rayon*2, plein );
    }
	
    /**
     * Construit un Cercle à partir d'un Carre et d'une couleur.<br />
     * Le centre du cercle sera obtenue via les coordonnées du Point min du Carre auxquelles on ajoute la moitié de la dimension des côtés.
     * @param couleur Couleur de l'objet.
     * @param c Carre qui définie le Cercle.
     */
    public Cercle ( Couleur couleur, Carre c ) {
		
	super ( couleur,
		new Point ( ( c.getA().getX() + c.getTaille()/2 ), ( c.getA().getY() + c.getTaille()/2 ) ),
		c.getTaille(),
		c.getTaille()
		);
    }
	
    /**
     * Construit un Cercle plein à partir d'un Carre et d'une couleur.<br />
     * Le centre du cercle sera obtenue via les coordonnées du Point min du Carre auxquelles on ajoute la moitié de la dimension des côtés.
     * @param couleur Couleur de l'objet.
     * @param c Carre qui définie le Cercle.
     * @param plein Booléen.
     */
    public Cercle ( Couleur couleur, Carre c, boolean plein ) {
		
	super ( couleur,
		new Point ( ( c.getA().getX() + c.getTaille()/2 ), ( c.getA().getY() + c.getTaille()/2 ) ),
		c.getTaille(),
		c.getTaille(),
		plein
		);
    }

    // Accesseurs //

    // Getter //
	
    /**
     * Retourne la valeur du rayon.
     * @return rayon int correspondant au rayon du Cercle.
     */
    public int getRayon () {
		
	return getLargeur()/2;
    }

    /**
     * Retourne la valeur du diamètre.
     * @return diamètre int correspondant au diamètre du Cercle.
     */
    public int getDiametre () {
		
	return getLargeur();
    }
	
    // Setter //
	
    /**
     * Permet d'attribuer une valeur au rayon.
     * @param rayon int correspondant au rayon du Cercle.
     */
    public void setRayon ( int rayon ) {
		
	setLargeur(rayon*2);
    }

    /**
     * Permet d'attribuer une valeur au diametre.
     * @param diametre int correspondant au diamètre du Cercle.
     */
    public void setDiametre ( int diametre ) {
		
	setLargeur(diametre);
    }

    /**
     * Redefinition ! Permet d'attribuer une valeur au diametre.
     * @param diametre int correspondant au diamètre du Cercle.
     */
    public void setLargeur ( int diametre ) {
		
	super.setLargeur(diametre);
	super.setHauteur(diametre);
    }

    /**
     * Redefinition ! Permet d'attribuer une valeur au diametre.
     * @param diametre int correspondant au diamètre du Cercle.
     */
    public void setHauteur ( int diametre ) {
		
	super.setLargeur(diametre);
	super.setHauteur(diametre);
    }
	
    // Méthodes //
       
	
    // Intersections //
	
    // Cercle - Point //
	
    /**
     * Méthode d'intersection précise entre un Cercle et un Point.<br />
     * Retourne vrai s'il y a collision.
     * @param p Point.
     * @return boolean Résultat du test.
     */
    public boolean intersection ( Point p ) {
		
	boolean collision = false;
		
	int dx = p.getX() - this.getO().getX();
	int dy = p.getY() - this.getO().getY();
		
	if ( ( dx * dx ) + ( dy * dy ) < ( getRayon() * getRayon() ) )
	    collision = true;
		
	return collision;
    }
	
    // Cercle - Ligne //
	
    /**
     * Méthode d'intersection précise entre un Cercle et une Ligne.<br />
     * Retourne vrai s'il y a collision.
     * @param l Ligne.
     * @return boolean Résultat du test.
     */
    public boolean intersection ( Ligne l ) {
		
	boolean collision = false;
		
	int ux = l.getB().getX() - l.getA().getX();
	int uy = l.getB().getY() - l.getA().getY();
	int acx = this.getO().getX() - l.getA().getX();
	int acy = this.getO().getY() - l.getA().getY();
		
	int numerateur = ux * acy - uy * acx;
		
	if ( numerateur < 0 )
	    numerateur = -numerateur;
		
	int denominateur = ( int ) ( Math.sqrt ( ux * ux + uy * uy ) );
	int ci = numerateur / denominateur;
		
	if ( ci < getRayon() )
	    collision = true;
		
	return collision;
    }
	
    // Cercle - Rectangle //
	
    /**
     * Méthode d'intersection précise entre un Cercle et un Rectangle.<br />
     * Retourne vrai s'il y a collision.
     * @param r Rectangle.
     * @return boolean Résultat du test.
     */
    public boolean intersection ( Rectangle r ) {
		
	boolean collision = false;
		
	int x = this.getO().getX();
	int y = this.getO().getY();

	if ( x < r.getA().getX() )
	    x = r.getA().getX();
		
	if ( x > ( r.getA().getX() + r.getLargeur() ) )
	    x = ( r.getA().getX() + r.getLargeur() );
		
	if ( y <  r.getA().getY() )
	    y = r.getA().getY();
		
	if ( y > ( r.getA().getY() + r.getHauteur() ) )
	    y = ( r.getA().getY() + r.getHauteur() );

	if ( ( this.getO().getX() - x ) * ( this.getO().getX() - x ) + ( this.getO().getY() - y ) * ( this.getO().getY() - y ) < getRayon() * getRayon() )
	    collision = true;
		
	return collision;
    }
	
    // Cercle - Ovale //
	
    // TODO : travail à faire, si l'envie vous prend :) //
	
    // Cercle - Cercle //
	
    /**
     * Méthode d'intersection précise entre un Cercle et un Cercle.<br />
     * Retourne vrai s'il y a collision.
     * @param c Cercle.
     * @return boolean Résultat du test.
     */
    public boolean intersection ( Cercle c ) {
		
	boolean collision = false;
		
	int dx = c.getO().getX() - this.getO().getX();
	int dy = c.getO().getY() - this.getO().getY();
	int ra = c.getRayon() + getRayon();
		
	if ( ( dx * dx ) + ( dy * dy ) <= ( ra * ra ) )
	    collision = true;
		
	return collision;
    }
	
    // Cercle - Triangle //
	
    // TODO : travail à faire, si l'envie vous prend :) //

    /**
     * Méthode toString.
     */
    public String toString(){
	return new String("Cercle de centre "+getO()+" et de rayon "+getRayon());
    }

    /**
     * Méthode equals.
     */
    public boolean equals(Object obj){
	if (obj==this) { 
            return true; 
        } 
  
        // Vérification du type du paramètre 
        if (obj instanceof Cercle) { 
            // Vérification des valeurs des attributs 
             Cercle other = (Cercle) obj; 
	     return super.equals(other) && getRayon()==other.getRayon();
	}
	return false;
    }
}
