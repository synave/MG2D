import MG2D.geometrie.*;

import java.awt.Color;

import javax.swing.JFrame;

import MG2D.Fenetre;

public class Test_Texture extends JFrame {
	
	public static void main ( String [] args ) {
		
		// Variables //
		
		Texture background = new Texture ( "img/bob.jpg", new Point ( 0, 0 ) );
		
		final int largeur = background.getLargeur();
		final int hauteur = background.getHauteur();
		
		// Fenêtre //
		
		Fenetre f = new Fenetre ( "Problem ?", largeur, hauteur );
		f.setBackground ( Color.black );
		
		int x = f.getMilieu().getX();
		int y = f.getMilieu().getY();
		
		Point a = new Point ( x - 128, y - 128 );
		Point b = new Point ( x + 128, y + 128 );
		
		f.ajouter ( background );
		
		Texture t = new Texture ( "img/t.png", a, b );

		f.ajouter ( t );
		
		int dx = -1, dy = -1;
		
		while ( true ) {
			
			try {
				
				Thread.sleep ( 2 );
			}
			
			catch ( Exception e ) {
				
				System.out.println ( e );
			}
			
			if ( t.getA().getX() == 0 )
				dx = 1;
			
			if ( t.getB().getX() == largeur )
				dx = -1;

			if ( t.getA().getY() == 0 )
				dy = 1;
			
			if ( t.getB().getY() == hauteur )
				dy = -1;
			
			t.getA().setX ( t.getA().getX() + dx );
			t.getA().setY ( t.getA().getY() + dy );
			
			t.getB().setX ( t.getB().getX() + dx );
			t.getB().setY ( t.getB().getY() + dy );
									
			f.rafraichir();
		}
	}
}
