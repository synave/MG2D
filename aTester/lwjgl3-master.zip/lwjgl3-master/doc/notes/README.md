### [Release notes for latest version](latest.md)

### [Release notes for all versions](full.md)

### Version History

* 2016-12-27 [3.1.1](3.1.1.md) (latest)
* 2016-10-30 [3.1.0](3.1.0.md)
* 2016-06-03 [3.0.0](3.0.0.md)
* 2015-11-20 [3.0.0 Beta](3.0.0b.md)
* 2015-07-13 [3.0.0 Alpha](3.0.0a.md)
