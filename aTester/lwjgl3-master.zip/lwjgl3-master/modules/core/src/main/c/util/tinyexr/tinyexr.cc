#define TINYEXR_IMPLEMENTATION
#include "tinyexr.h"
